import base64
import hashlib
import json
import os
import re
import secrets
import sys
import urllib.parse
import urllib.request
import zipfile
import zipimport
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from approval import settings_path


APP_VERSION = "2.3.4"
CHECK_INTERVAL_SECONDS = 21600
MAX_MANIFEST_BYTES = 16384
MAX_INSTALLER_BYTES = 400_000_000
MAX_PATCH_BYTES = 8_000_000
MAX_PATCH_CONTENT_BYTES = 24_000_000
DEFAULT_FEED_URL = "https://raw.githubusercontent.com/lolloolminecraft/erzhanpc/main/channel.json"
DEFAULT_PUBLIC_KEY = "17017d88c7ee38995874c2a894d150fe51b30bb022620b07fe41f82d8bc79c1d"
_active_patch = None
_active_version = APP_VERSION


def _https_url(value):
    if not isinstance(value, str) or len(value) > 1024:
        raise ValueError("Invalid update URL")
    parts = urllib.parse.urlsplit(value)
    if parts.scheme != "https" or not parts.netloc or parts.username or parts.password or parts.fragment:
        raise ValueError("Update URLs must use HTTPS without credentials")
    return value


def validate_settings(url, public_key):
    _https_url(url)
    if not re.fullmatch(r"[0-9a-fA-F]{64}", public_key or ""):
        raise ValueError("The publisher's Ed25519 public key must contain 64 hexadecimal characters")
    return {"feed_url": url, "public_key": public_key.lower()}


def config_path():
    return settings_path().with_name("updates.json")


def load_settings():
    try:
        data = json.loads(config_path().read_text(encoding="utf-8"))
        return validate_settings(data["feed_url"], data["public_key"])
    except (ValueError, KeyError, TypeError, OSError):
        return validate_settings(DEFAULT_FEED_URL, DEFAULT_PUBLIC_KEY) if DEFAULT_PUBLIC_KEY else None


def save_settings(url, public_key):
    config = validate_settings(url, public_key)
    target = config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".pending-" + secrets.token_hex(4))
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(config, stream, ensure_ascii=False, indent=2)
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return config


def canonical_payload(version, url, sha256):
    return json.dumps({"sha256": sha256, "url": url, "version": version},
                      sort_keys=True, separators=(",", ":")).encode("utf-8")


def canonical_patch_payload(version, base_version, url, sha256):
    return json.dumps({"kind": "patch", "version": version, "base_version": base_version,
                       "sha256": sha256, "url": url}, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def canonical_idle_payload(version):
    return json.dumps({"kind": "idle", "version": version}, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def version_tuple(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{1,4}\.\d{1,4}\.\d{1,4}", value):
        raise ValueError("Invalid update version")
    return tuple(int(part) for part in value.split("."))


def verify_manifest(data, public_key, current_version=APP_VERSION):
    if not isinstance(data, dict):
        raise ValueError("Update manifest must be an object")
    if data.get("kind") == "idle":
        version_tuple(data.get("version"))
        try:
            key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key))
            key.verify(base64.b64decode(data["signature"], validate=True),
                       canonical_idle_payload(data["version"]))
        except Exception as error:
            raise ValueError("Update channel signature verification failed") from error
        if version_tuple(data["version"]) != version_tuple(APP_VERSION):
            raise ValueError("Update channel baseline does not match this application")
        return None
    version = data.get("version")
    url = data.get("url")
    digest = data.get("sha256")
    signature = data.get("signature")
    version_tuple(version)
    _https_url(url)
    kind = data.get("kind", "installer")
    if kind not in {"installer", "patch"}:
        raise ValueError("Unknown update type")
    expected_suffix = ".zip" if kind == "patch" else ".exe"
    if not url.lower().split("?", 1)[0].endswith(expected_suffix):
        raise ValueError("Unexpected update file extension")
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("Invalid release SHA-256")
    if not isinstance(signature, str) or len(signature) > 128:
        raise ValueError("Invalid release signature")
    base_version = data.get("base_version")
    if kind == "patch":
        version_tuple(base_version)
        if base_version != APP_VERSION:
            raise ValueError("This patch requires a different application baseline")
        if version_tuple(version) <= version_tuple(base_version):
            raise ValueError("Patch version must be above baseline")
        signed = canonical_patch_payload(version, base_version, url, digest)
    else:
        signed = canonical_payload(version, url, digest)
    try:
        signature_bytes = base64.b64decode(signature, validate=True)
        key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key))
        key.verify(signature_bytes, signed)
    except Exception as error:
        raise ValueError("Update signature verification failed") from error
    release = {"version": version, "url": url, "sha256": digest, "kind": kind,
               "signature": signature}
    if kind == "patch":
        release["base_version"] = base_version
    return release if version_tuple(version) > version_tuple(current_version) else None


def check_update(settings, current_version=None, open_url=None):
    opener = open_url or urllib.request.urlopen
    request = urllib.request.Request(settings["feed_url"], headers={"User-Agent": "ErzhanPC/" + APP_VERSION})
    with opener(request, timeout=12) as response:
        _https_url(response.geturl())
        body = response.read(MAX_MANIFEST_BYTES + 1)
    if len(body) > MAX_MANIFEST_BYTES:
        raise ValueError("Update manifest is too large")
    return verify_manifest(json.loads(body.decode("utf-8")), settings["public_key"],
                           current_version or installed_version())


def installed_version():
    return _active_version


def patch_root():
    return settings_path().parent / "updates" / "patches"


def _inspect_patch(archive):
    count = 0
    total = 0
    with zipfile.ZipFile(archive) as source:
        for entry in source.infolist():
            name = entry.filename
            if entry.is_dir() or name.startswith("/") or "\\" in name or ".." in name.split("/"):
                raise ValueError("Invalid patch entry")
            if not re.fullmatch(r"[a-z][a-z0-9_]*\.py|icons/[a-z0-9-]+\.svg", name):
                raise ValueError("Patch contains an unsupported file")
            if name in {"launcher.py", "update_engine.py"}:
                raise ValueError("Core updater can only change through a new signed installer")
            if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Symbolic links are not accepted in patches")
            count += 1
            total += entry.file_size
            if count > 75 or total > MAX_PATCH_CONTENT_BYTES:
                raise ValueError("Patch contents are too large")
    if not count:
        raise ValueError("Patch archive is empty")


def _verified_patch_data(settings):
    pointer = patch_root() / "current.json"
    data = json.loads(pointer.read_text(encoding="utf-8"))
    version = data["version"]
    version_tuple(version)
    directory = patch_root() / ("patch-" + version)
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    release = verify_manifest(manifest, settings["public_key"], APP_VERSION)
    if not release or release["kind"] != "patch" or release["version"] != version:
        raise ValueError("Installed update metadata failed verification")
    archive = directory / "patch.zip"
    if archive.stat().st_size > MAX_PATCH_BYTES or hashlib.sha256(archive.read_bytes()).hexdigest() != release["sha256"]:
        raise ValueError("Installed update content failed SHA-256 verification")
    _inspect_patch(archive)
    return archive, release


def activate_verified_patch(settings=None):
    global _active_patch, _active_version
    settings = settings if settings is not None else load_settings()
    if not settings or not (patch_root() / "current.json").exists():
        return False
    try:
        archive, release = _verified_patch_data(settings)
        importer = zipimport.zipimporter(str(archive))
        sys.meta_path.insert(0, importer)
        _active_patch = archive
        _active_version = release["version"]
        return True
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        error_path = settings_path().with_name("update-error.log")
        error_path.parent.mkdir(parents=True, exist_ok=True)
        error_path.write_text(str(error), encoding="utf-8")
        return False


def active_patch_path():
    return _active_patch


def download_verified_patch(manifest, settings, open_url=None, progress_callback=None):
    release = verify_manifest(manifest, settings["public_key"], APP_VERSION)
    if not release or release["kind"] != "patch":
        raise ValueError("Patch was not signed for this application")
    directory = patch_root()
    directory.mkdir(parents=True, exist_ok=True)
    opener = open_url or urllib.request.urlopen
    request = urllib.request.Request(release["url"], headers={"User-Agent": "ErzhanPC/" + APP_VERSION})
    stage = directory / ("incoming-" + secrets.token_hex(12))
    stage.mkdir()
    target = directory / ("patch-" + release["version"])
    total = 0
    digest = hashlib.sha256()
    try:
        archive = stage / "patch.zip"
        with opener(request, timeout=30) as response, archive.open("xb") as stream:
            _https_url(response.geturl())
            expected = int(getattr(response, "headers", {}).get("Content-Length", 0) or 0)
            while True:
                chunk = response.read(512 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_PATCH_BYTES:
                    raise ValueError("Patch exceeds the 8 MB download limit")
                digest.update(chunk)
                stream.write(chunk)
                if progress_callback:
                    progress_callback(total, expected)
            stream.flush()
            os.fsync(stream.fileno())
        if not total or digest.hexdigest() != release["sha256"]:
            raise ValueError("Downloaded patch failed SHA-256 verification")
        _inspect_patch(archive)
        (stage / "manifest.json").write_text(json.dumps(manifest, sort_keys=True), encoding="utf-8")
        if target.exists():
            raise FileExistsError("Patch version already exists")
        os.replace(stage, target)
        temp_pointer = directory / ("pointer-" + secrets.token_hex(8) + ".pending")
        try:
            temp_pointer.write_text(json.dumps({"version": release["version"]}), encoding="utf-8")
            os.replace(temp_pointer, directory / "current.json")
        finally:
            temp_pointer.unlink(missing_ok=True)
        return target / "patch.zip"
    finally:
        if stage.exists():
            (stage / "patch.zip").unlink(missing_ok=True)
            (stage / "manifest.json").unlink(missing_ok=True)
            stage.rmdir()


def download_verified_installer(manifest, output_directory=None, open_url=None, progress_callback=None):
    root = Path(output_directory) if output_directory else settings_path().parent / "updates"
    root.mkdir(parents=True, exist_ok=True)
    opener = open_url or urllib.request.urlopen
    request = urllib.request.Request(manifest["url"], headers={"User-Agent": "ErzhanPC/" + APP_VERSION})
    temporary = root / ("download-" + secrets.token_hex(12) + ".pending")
    target = root / ("ErzhanPC_Setup_" + manifest["version"] + ".exe")
    digest = hashlib.sha256()
    total = 0
    try:
        with opener(request, timeout=30) as response, temporary.open("xb") as stream:
            _https_url(response.geturl())
            expected = int(getattr(response, "headers", {}).get("Content-Length", 0) or 0)
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_INSTALLER_BYTES:
                    raise ValueError("Update exceeds the 400 MB limit")
                digest.update(chunk)
                stream.write(chunk)
                if progress_callback:
                    progress_callback(total, expected)
            stream.flush()
            os.fsync(stream.fileno())
        if not total or digest.hexdigest() != manifest["sha256"]:
            raise ValueError("Downloaded installer SHA-256 mismatch")
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return target
