import ctypes
import os
import secrets
from ctypes import wintypes
from pathlib import Path


class DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _crypt(data, protect):
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI is required")
    buffer = ctypes.create_string_buffer(data)
    original = DataBlob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    result = DataBlob()
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    method = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    method.argtypes = [
        ctypes.POINTER(DataBlob), ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DataBlob),
    ]
    method.restype = wintypes.BOOL
    if not method(ctypes.byref(original), None, None, None, None, 1, ctypes.byref(result)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(result.pbData, result.cbData)
    finally:
        free = ctypes.windll.kernel32.LocalFree
        free.argtypes = [ctypes.c_void_p]
        free.restype = ctypes.c_void_p
        free(result.pbData)


def secret_path(filename="runtime.secret"):
    return Path(os.environ["APPDATA"]) / "ErzhanPC" / filename


def save_api_key(value):
    key = value.strip()
    if not key:
        raise ValueError("API key is empty")
    path = secret_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(_crypt(key.encode("utf-8"), True))
    temporary.replace(path)


def read_api_key():
    path = secret_path()
    if not path.is_file():
        return None
    return _crypt(path.read_bytes(), False).decode("utf-8")


def save_transcription_key(value):
    key = value.strip()
    if not key:
        raise ValueError("Transcription API key is empty")
    path = secret_path("transcription.secret")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(_crypt(key.encode("utf-8"), True))
    temporary.replace(path)


def read_transcription_key():
    path = secret_path("transcription.secret")
    if not path.is_file():
        return None
    return _crypt(path.read_bytes(), False).decode("utf-8")


def get_or_create_local_token():
    path = secret_path("local-mcp.secret")
    try:
        token = _crypt(path.read_bytes(), False).decode("ascii")
    except FileNotFoundError:
        token = secrets.token_urlsafe(36)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_bytes(_crypt(token.encode("ascii"), True))
        temporary.replace(path)
    if not token or any(character in token for character in "\r\n,:"):
        raise ValueError("Invalid saved local MCP token")
    return token
