import asyncio
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from approval import ApprovalBroker
from instance_guard import acquire_instance, release_instance
from secret_store import get_or_create_local_token, secret_path
from secure_transport import LocalTokenMiddleware, create_local_token, local_auth_probe, run_secured
from jobs import PowerShellJobs
import windows_ops


class ApprovalPolicyTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"APPDATA": self.directory.name})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.directory.cleanup()

    def test_private_default_and_shell_block(self):
        broker = ApprovalBroker(lambda *a: "once")
        self.assertFalse(broker.enabled)
        self.assertEqual(broker.mode, "private")
        broker.set_enabled(True)
        with self.assertRaisesRegex(PermissionError, "Private"):
            broker.request("shell", "Get-ChildItem")
        broker.request("input", "mouse move")

    def test_full_read_fast_and_sensitive_confirmed_each_time(self):
        decisions = []

        def ask(capability, detail):
            decisions.append(capability)
            return "always"

        broker = ApprovalBroker(ask)
        broker.set_mode("full")
        broker.set_enabled(True)
        for capability in ["screen", "files_read", "windows", "devices"]:
            broker.request(capability, "observe")
        self.assertEqual(decisions, [])
        with self.assertRaises(PermissionError):
            broker.request("shell", "Get-ChildItem")
        self.assertEqual(decisions, ["shell"])
        self.assertNotIn("shell", broker.allow_always)

    def test_existing_shell_always_is_revoked_on_upgrade(self):
        path = Path(self.directory.name) / "ErzhanPC" / "settings.json"
        path.parent.mkdir(parents=True)
        path.write_text(json.dumps({"enabled": True, "allow_always": ["shell", "files_write", "screen"]}))
        broker = ApprovalBroker(lambda *a: "deny")
        self.assertEqual(broker.mode, "private")
        self.assertEqual(broker.allow_always, {"screen"})
        with self.assertRaises(PermissionError):
            broker.request("shell", "bad")

    def test_audit_has_no_command_or_secret(self):
        broker = ApprovalBroker(lambda *a: "once")
        broker.set_enabled(True)
        broker.request("input", "secret-token-do-not-log")
        log = broker.path.with_name("activity.jsonl").read_text()
        self.assertNotIn("secret-token-do-not-log", log)
        self.assertIn("approved", log)

    def test_revocation_and_mode_switch(self):
        broker = ApprovalBroker(lambda *a: "once")
        broker.set_enabled(True)
        broker.set_mode("full")
        broker.request("screen", "screen")
        broker.set_enabled(False)
        with self.assertRaises(PermissionError):
            broker.request("screen", "screen")
        broker.set_mode("private")
        self.assertEqual(ApprovalBroker(lambda *a: "deny").mode, "private")

    def test_time_limited_input_lease(self):
        calls = []
        broker = ApprovalBroker(lambda capability, detail: calls.append(capability) or "once")
        broker.set_mode("full")
        broker.set_enabled(True)
        broker.grant_input_lease(300)
        broker.request("input", "click")
        self.assertEqual(calls, [])
        with patch("approval.time.monotonic", return_value=broker.input_lease_until + 1):
            broker.request("input", "click again")
        self.assertEqual(calls, ["input"])
        broker.set_enabled(False)
        self.assertEqual(broker.status()["input_lease_seconds"], 0)

    def test_two_pc_configs_do_not_share_live_approval_state(self):
        with tempfile.TemporaryDirectory() as second_pc:
            first = ApprovalBroker(lambda *a: "deny")
            first.set_mode("full")
            first.set_enabled(True)
            with patch.dict(os.environ, {"APPDATA": second_pc}):
                other = ApprovalBroker(lambda *a: "deny")
                self.assertFalse(other.enabled)
                self.assertEqual(other.mode, "private")
            restarted = ApprovalBroker(lambda *a: "deny")
            self.assertFalse(restarted.enabled)
            self.assertEqual(restarted.mode, "full")

    def test_risk_mode_approves_input_but_requires_shell_and_files_confirmation(self):
        asked = []
        broker = ApprovalBroker(lambda capability, detail: asked.append(capability) or "once")
        broker.set_mode("full")
        broker.set_enabled(True)
        broker.grant_automation("risk", 900)
        broker.request("input", "click")
        self.assertEqual(asked, [])
        broker.request("files_write", "change important file")
        broker.request("shell", "run command")
        self.assertEqual(asked, ["files_write", "shell"])
        broker.stop_automation()
        broker.request("input", "click")
        self.assertEqual(asked[-1], "input")

    def test_crazy_mode_expires_and_does_not_persist(self):
        asked = []
        broker = ApprovalBroker(lambda capability, detail: asked.append(capability) or "once")
        broker.set_mode("full")
        broker.set_enabled(True)
        broker.grant_automation("crazy", 120)
        for capability in ("shell", "files_write", "media_cloud", "input"):
            broker.request(capability, "operation")
        self.assertEqual(asked, [])
        self.assertEqual(broker.status()["automation_profile"], "crazy")
        restarted = ApprovalBroker(lambda *a: "deny")
        self.assertEqual(restarted.status()["automation_profile"], "manual")
        with patch("approval.time.monotonic", return_value=broker.automation_until + 1):
            broker.request("input", "new input")
        self.assertEqual(asked, ["input"])
        broker.set_enabled(False)
        self.assertEqual(broker.status()["automation_profile"], "manual")

    def test_custom_approval_hotkey_is_validated_and_saved(self):
        broker = ApprovalBroker(lambda *a: "deny")
        broker.set_allow_shortcut("Ctrl+Alt+K")
        self.assertEqual(ApprovalBroker(lambda *a: "deny").allow_shortcut, "Ctrl+Alt+K")
        with self.assertRaises(ValueError):
            broker.set_allow_shortcut("K")


class LocalTransportTests(unittest.TestCase):
    def test_token_is_random(self):
        self.assertNotEqual(create_local_token(), create_local_token())

    def test_local_token_survives_restart_and_is_protected(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"APPDATA": directory}), patch(
                "secret_store._crypt", side_effect=lambda data, protect: data[::-1]
            ):
                first = get_or_create_local_token()
                second = get_or_create_local_token()
                self.assertEqual(first, second)
                self.assertGreater(len(first), 36)
                self.assertNotEqual(secret_path("local-mcp.secret").read_bytes(), first.encode())

    @unittest.skipUnless(os.name == "nt", "Windows DPAPI and named mutex required")
    def test_windows_token_and_instance_mutex(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"APPDATA": directory}):
                first = get_or_create_local_token()
                self.assertEqual(first, get_or_create_local_token())
                self.assertNotIn(first.encode(), secret_path("local-mcp.secret").read_bytes())
        handle = acquire_instance()
        self.assertIsNotNone(handle)
        try:
            self.assertIsNone(acquire_instance())
        finally:
            release_instance(handle)

    def test_local_auth_probe_uses_expected_header(self):
        with patch("secure_transport.urllib.request.build_opener") as build:
            response = build.return_value.open.return_value.__enter__.return_value
            response.status = 200
            response.read.return_value = b"ok"
            self.assertTrue(local_auth_probe("secret-token"))
            request = build.return_value.open.call_args.args[0]
            self.assertEqual(request.get_header("X-erzhan-local-auth"), "secret-token")
            self.assertEqual(request.full_url, "http://127.0.0.1:8787/__erzhan/auth-health")

    def test_http_rejects_missing_token_and_accepts_matching_token(self):
        async def app(scope, receive, send):
            await send({"type": "http.response.start", "status": 200, "headers": []})
            await send({"type": "http.response.body", "body": b"ok"})

        async def check(headers, path="/mcp"):
            messages = []

            async def receive():
                return {"type": "http.request", "body": b""}

            async def send(message):
                messages.append(message)

            await LocalTokenMiddleware(app, "test-secret")(
                {"type": "http", "path": path, "headers": headers}, receive, send
            )
            return messages[0]["status"]

        self.assertEqual(asyncio.run(check([])), 401)
        self.assertEqual(asyncio.run(check([(b"x-erzhan-local-auth", b"wrong")])), 401)
        self.assertEqual(asyncio.run(check([(b"x-erzhan-local-auth", b"test-secret")])), 200)
        self.assertEqual(asyncio.run(check([], "/__erzhan/auth-health")), 401)
        self.assertEqual(asyncio.run(check([(b"x-erzhan-local-auth", b"test-secret")],
                                           "/__erzhan/auth-health")), 200)

    def test_server_uses_explicit_packaged_http_backend(self):
        server = Mock()
        with patch("uvicorn.run") as launch:
            run_secured(server, "local-test-token", 18789)
        self.assertEqual(launch.call_args.kwargs["http"], "h11")
        self.assertEqual(launch.call_args.kwargs["loop"], "asyncio")
        self.assertEqual(launch.call_args.kwargs["ws"], "none")
        self.assertEqual(launch.call_args.kwargs["host"], "127.0.0.1")
        self.assertIsNone(launch.call_args.kwargs["log_config"])

    def test_server_logging_supports_windowed_executable(self):
        import uvicorn

        with patch.object(sys, "stderr", None), patch.object(sys, "stdout", None):
            config = uvicorn.Config(app=Mock(), log_config=None, log_level="warning")
        self.assertIsNone(config.log_config)

    def test_server_startup_error_writes_diagnostics(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"APPDATA": directory}):
                with patch("uvicorn.run", side_effect=ImportError("missing server backend")):
                    run_secured(Mock(), "local-test-token", 18789)
            error_log = Path(directory) / "ErzhanPC" / "server-error.log"
            self.assertIn("missing server backend", error_log.read_text())


class FileTests(unittest.TestCase):
    def test_rename_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "before.txt"
            destination = Path(directory) / "after.txt"
            source.write_text("hello")
            destination.write_text("keep")
            with self.assertRaises(FileExistsError):
                windows_ops.rename_file(str(source), destination.name)
            self.assertEqual(destination.read_text(), "keep")
            self.assertEqual(windows_ops.rename_file(str(source), "renamed.txt")["new_path"],
                             str(Path(directory) / "renamed.txt"))
            with self.assertRaises(ValueError):
                windows_ops.rename_file(str(destination), "../escape.txt")

    def test_desktop_batch_rejects_invalid_arguments(self):
        with self.assertRaises(ValueError):
            windows_ops.perform_actions([])
        with self.assertRaises(ValueError):
            windows_ops.perform_actions([{"kind": "shell", "command": "whoami"}])


class BackgroundTests(unittest.TestCase):
    def test_powershell_job_returns_immediately(self):
        with patch("jobs.shutil.which", return_value=sys.executable):
            runner = PowerShellJobs()
            started = runner.start("ignored")
            self.assertEqual(started["status"], "running")
            for _ in range(50):
                status = runner.status(started["job_id"])
                if status["status"] != "running":
                    break
                import time
                time.sleep(0.02)
            self.assertEqual(status["status"], "finished")
            self.assertIsInstance(status["exit_code"], int)


if __name__ == "__main__":
    unittest.main()
