import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tunnel_runtime import reconnect_delay, runtime_auth_headers, tunnel_command, tunnel_ready


class TunnelRuntimeTests(unittest.TestCase):
    def test_reconnect_backoff_is_bounded(self):
        self.assertEqual([reconnect_delay(count) for count in range(1, 8)], [3, 6, 12, 24, 48, 60, 60])

    def test_local_auth_is_present_in_runtime_and_discovery_headers(self):
        expected = "X-Erzhan-Local-Auth: local-test-token"
        headers = runtime_auth_headers("local-test-token")
        self.assertEqual(headers["MCP_EXTRA_HEADERS"], expected)
        self.assertEqual(headers["MCP_DISCOVERY_EXTRA_HEADERS"], expected)
        self.assertEqual(headers["ERZHAN_LOCAL_TOKEN"], "local-test-token")
        with self.assertRaises(ValueError):
            runtime_auth_headers("danger\r\nFake: yes")
    def test_command_uses_automatic_health_port(self):
        command = tunnel_command("C:\\Apps\\tunnel-client.exe", "erzhan-pc", "C:\\Data\\tunnel-health.url")
        self.assertEqual(command[1:4], ["run", "--profile", "erzhan-pc"])
        self.assertIn(["--mcp.extra-headers", "X-Erzhan-Local-Auth: env:ERZHAN_LOCAL_TOKEN"],
                      [command[i:i + 2] for i in range(len(command) - 1)])
        self.assertIn(["--mcp.discovery-extra-headers", "X-Erzhan-Local-Auth: env:ERZHAN_LOCAL_TOKEN"],
                      [command[i:i + 2] for i in range(len(command) - 1)])
        self.assertEqual(command[-4:], ["--health.listen-addr", "127.0.0.1:0", "--health.url-file",
                                        "C:\\Data\\tunnel-health.url"])

    def test_ready_probe_uses_only_local_loopback(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "health.url"
            path.write_text("http://127.0.0.1:34567/", encoding="utf-8")
            with patch("tunnel_runtime.urllib.request.build_opener") as make_opener:
                make_opener.return_value.open.return_value.__enter__.return_value.status = 200
                self.assertTrue(tunnel_ready(path))
                make_opener.return_value.open.assert_called_once_with("http://127.0.0.1:34567/readyz", timeout=0.25)
                self.assertEqual(make_opener.call_args.args[0].proxies, {})

    def test_ready_probe_rejects_nonlocal_urls(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "health.url"
            for address in ["https://127.0.0.1:34567", "http://example.com:8080", "http://127.0.0.1:8080/private"]:
                path.write_text(address, encoding="utf-8")
                self.assertFalse(tunnel_ready(path))
            self.assertFalse(tunnel_ready(Path(directory) / "missing"))


if __name__ == "__main__":
    unittest.main()
