import json
import ctypes
from ctypes import wintypes
import os
import re
import socket
import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPushButton,
    QSystemTrayIcon,
    QTextEdit,
    QVBoxLayout,
)

from approval import ApprovalBroker, CAPABILITIES, settings_path
from activity_hud import ActivityHud
from bridge import create_bridge
from dashboard import Dashboard
from hotkeys import GlobalApprovalHotkey
from secret_store import read_api_key, save_api_key, save_transcription_key
from secure_transport import create_local_token, run_secured
from tunnel_runtime import runtime_auth_headers, tunnel_command
from ui_icons import brand_icon, icon
import update_engine


class ApprovalSignals(QObject):
    ask = Signal(str, str, object)
    activity = Signal(str)
    update_result = Signal(object)


class PermissionDialog(QDialog):
    def __init__(self, capability, detail, shortcut):
        super().__init__()
        self.choice = "deny"
        self.setWindowTitle("Erzhan PC | Permission")
        self.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)
        self.setWindowOpacity(0.95)
        self.setFixedSize(570, 235)
        self.setStyleSheet("""
            QDialog { background: #182439; color: #fdfcfc; border: 1px solid #506581; border-radius: 18px; }
            QLabel, QTextEdit, QPushButton { font-family: 'JetBrains Mono', 'Consolas'; font-size: 11pt; }
            QLabel { color: #fdfcfc; }
            QTextEdit { background: #24334b; color: #fdfcfc; border: 1px solid #405571; border-radius: 9px; }
            QPushButton { background: #24334b; color: #fdfcfc; border: 1px solid #506581; padding: 8px 14px; border-radius: 9px; }
            QPushButton:hover { border: 1px solid #007aff; }
            QPushButton#allow { border: 1px solid #30d158; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        title = QLabel(f"[?] ChatGPT requests {CAPABILITIES[capability]}")
        title.setWordWrap(True)
        layout.addWidget(title)
        details = QTextEdit()
        details.setReadOnly(True)
        details.setPlainText(detail)
        layout.addWidget(details, 1)
        row = QHBoxLayout()
        marker = "[PS]" if capability == "shell" else "[FS]" if capability.startswith("files") else "[UI]"
        row.addWidget(QLabel(f"{marker}  Hotkey: {shortcut}"))
        row.addStretch()
        deny = QPushButton("Deny")
        deny.setIcon(icon("x"))
        deny.clicked.connect(lambda: self.set_choice("deny"))
        allow = QPushButton("Allow once")
        allow.setIcon(icon("check", "#4ade80"))
        allow.setObjectName("allow")
        allow.clicked.connect(lambda: self.set_choice("once"))
        row.addWidget(deny)
        row.addWidget(allow)
        layout.addLayout(row)
        screen = QApplication.primaryScreen()
        if screen:
            area = screen.availableGeometry()
            self.move(area.x() + (area.width() - self.width()) // 2,
                      area.y() + area.height() - self.height() - 42)

    def set_choice(self, choice):
        self.choice = choice
        self.accept()


class TrayApp(QObject):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.signals = ApprovalSignals()
        self.signals.ask.connect(self.show_approval)
        self.signals.activity.connect(self.record_activity)
        self.signals.update_result.connect(self.handle_update_result)
        self.broker = ApprovalBroker(self.ask_user)
        self.local_token = create_local_token()
        self.last_activity = "No requests"
        self.tunnel_process = None
        self.tunnel_log = None
        self.tunnel_health_file = settings_path().with_name("tunnel-health.url")
        self.server_wait_attempts = 0
        self.dashboard = None
        self.active_dialog = None
        self.hotkey = GlobalApprovalHotkey(self.broker.allow_shortcut)
        self.hotkey.pressed.connect(self.approve_pending)
        self.hotkey.failed.connect(lambda reason: self.tray.showMessage("Approval hotkey unavailable", reason))
        self.update_busy = False
        self.tray = QSystemTrayIcon(self.make_icon(), app)
        self.menu = QMenu()
        self.toggle = QAction("Start access")
        self.toggle.triggered.connect(self.toggle_access)
        self.menu.addAction(self.toggle)
        self.private_action = QAction("Private mode")
        self.private_action.triggered.connect(lambda: self.change_mode("private"))
        self.menu.addAction(self.private_action)
        self.full_action = QAction("Full mode")
        self.full_action.triggered.connect(lambda: self.change_mode("full"))
        self.menu.addAction(self.full_action)
        input_lease = QAction("Allow UI input for 5 minutes")
        input_lease.triggered.connect(self.grant_input_lease)
        self.menu.addAction(input_lease)
        self.menu.addSeparator()
        risk = QAction("Risk mode | 15 minutes")
        risk.setIcon(icon("shield-check"))
        risk.triggered.connect(lambda: self.start_automation("risk"))
        self.menu.addAction(risk)
        crazy = QAction("Crazy mode | 2 minutes")
        crazy.setIcon(icon("zap", "#f97373"))
        crazy.triggered.connect(lambda: self.start_automation("crazy"))
        self.menu.addAction(crazy)
        stop_auto = QAction("Stop automatic approvals")
        stop_auto.setIcon(icon("power"))
        stop_auto.triggered.connect(self.stop_automation)
        self.menu.addAction(stop_auto)
        self.menu.addSeparator()
        configure = QAction("Configure secure tunnel")
        configure.triggered.connect(self.configure_tunnel)
        self.menu.addAction(configure)
        check_update = QAction("Check for signed updates")
        check_update.triggered.connect(lambda: self.check_for_updates(True))
        self.menu.addAction(check_update)
        configure_update = QAction("Configure update publisher")
        configure_update.triggered.connect(self.configure_updates)
        self.menu.addAction(configure_update)
        transcription = QAction("Configure speech transcription key")
        transcription.triggered.connect(self.configure_transcription)
        self.menu.addAction(transcription)
        status = QAction("Open control center")
        status.setIcon(icon("settings"))
        status.triggered.connect(self.show_status)
        self.menu.addAction(status)
        self.menu.addSeparator()
        quit_action = QAction("Quit Erzhan PC")
        quit_action.triggered.connect(self.app.quit)
        self.menu.addAction(quit_action)
        self.tray.setContextMenu(self.menu)
        self.tray.setToolTip(f"Erzhan PC | {socket.gethostname()}")
        self.tray.activated.connect(self.on_tray_activation)
        self.refresh()
        self.tray.show()
        self.hud = ActivityHud(self)
        self.hud.show()
        self.hotkey.start()
        self.server = create_bridge(self.broker, self.activity, 8787)
        self.thread = threading.Thread(target=run_secured, args=(self.server, self.local_token, 8787), daemon=True)
        self.thread.start()
        self.app.aboutToQuit.connect(self.close_tunnel)
        self.app.aboutToQuit.connect(self.hotkey.stop)
        if self.broker.enabled:
            self.start_tunnel()
        self.update_timer = QTimer(self)
        self.update_timer.setInterval(update_engine.CHECK_INTERVAL_SECONDS * 1000)
        self.update_timer.timeout.connect(lambda: self.check_for_updates(False))
        self.update_timer.start()
        QTimer.singleShot(15000, lambda: self.check_for_updates(False))

    def configure_updates(self):
        current = update_engine.load_settings() or {}
        url, accepted = QInputDialog.getText(None, "Verified updates", "HTTPS signed manifest URL:",
                                              text=current.get("feed_url", ""))
        if not accepted:
            return
        public_key, accepted = QInputDialog.getText(None, "Update publisher", "Publisher Ed25519 public key (64 hex characters):",
                                                    text=current.get("public_key", ""))
        if not accepted:
            return
        try:
            update_engine.save_settings(url.strip(), public_key.strip())
        except ValueError as error:
            QMessageBox.warning(None, "Update configuration", str(error))
            return
        QMessageBox.information(None, "Updates", "Verified publisher configured. Future updates may be small signed patches; publisher changes require local approval.")
        if self.dashboard:
            self.dashboard.refresh_status()

    def configure_transcription(self):
        result = QMessageBox.question(None, "Cloud transcription",
                                      "Video speech transcription uploads audio to OpenAI and may incur API charges.\nStore a separate transcription API key on this Windows user account?",
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if result != QMessageBox.Yes:
            return
        key, accepted = QInputDialog.getText(None, "Speech transcription", "OpenAI API key (stored with Windows DPAPI):", QLineEdit.Password)
        if accepted and key.strip():
            save_transcription_key(key)
            QMessageBox.information(None, "Speech transcription", "Speech API key saved locally. Every audio upload still asks for approval.")

    def check_for_updates(self, manual=False):
        if self.update_busy:
            return
        settings = update_engine.load_settings()
        if not settings:
            if manual:
                self.configure_updates()
            return
        self.update_busy = True

        def work():
            try:
                release = update_engine.check_update(settings)
                self.signals.update_result.emit({"stage": "check", "release": release, "manual": manual})
            except Exception as error:
                self.signals.update_result.emit({"stage": "check", "error": str(error), "manual": manual})

        threading.Thread(target=work, daemon=True).start()

    def handle_update_result(self, result):
        self.update_busy = False
        if result.get("error"):
            self.last_activity = "Update check failed"
            if result.get("manual"):
                QMessageBox.warning(None, "Updates", str(result["error"]))
            return
        if result["stage"] == "check":
            release = result.get("release")
            if release is None:
                if result.get("manual"):
                    QMessageBox.information(None, "Updates", "You have the latest verified version.")
                return
            if release.get("kind") != "patch":
                decision = QMessageBox.question(None, "Verified update available",
                                                f"Erzhan PC {release['version']} has a valid publisher signature. Download and verify its installer?",
                                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if decision != QMessageBox.Yes:
                    return
            self.update_busy = True

            def download():
                try:
                    if release.get("kind") == "patch":
                        path = update_engine.download_verified_patch(release, settings=update_engine.load_settings())
                    else:
                        path = update_engine.download_verified_installer(release)
                    self.signals.update_result.emit({"stage": "download", "path": str(path),
                                                     "kind": release.get("kind"), "version": release["version"]})
                except Exception as error:
                    self.signals.update_result.emit({"stage": "download", "error": str(error), "manual": True})

            threading.Thread(target=download, daemon=True).start()
            return
        patch = result.get("kind") == "patch"
        decision = QMessageBox.question(None, "Activate verified update?",
                                        f"Version {result['version']} was verified.\n"
                                        + ("Restart Erzhan PC to activate the small patch?" if patch else
                                           "Install the new version? The current app will close."),
                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if decision == QMessageBox.Yes:
            try:
                if patch:
                    subprocess.Popen([sys.executable, "--wait-for", str(os.getpid()), "--show"], shell=False, close_fds=True)
                else:
                    subprocess.Popen([result["path"]], shell=False, close_fds=True)
                self.app.quit()
            except OSError as error:
                QMessageBox.warning(None, "Update installer failed", str(error))

    def tunnel_settings(self):
        try:
            return json.loads(settings_path().with_name("tunnel.json").read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return {}

    def configure_tunnel(self):
        current = self.tunnel_settings()
        suggested = current.get("path", str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "ErzhanPC" / "tunnel-client.exe"))
        if Path(suggested).is_file():
            path = suggested
        else:
            path, _ = QFileDialog.getOpenFileName(None, "Select official tunnel-client.exe", suggested, "Windows programs (*.exe)")
        if not path:
            return
        tunnel_id, ok = QInputDialog.getText(None, "Tunnel ID", "Paste tunnel ID from OpenAI Platform:")
        if not ok:
            return
        tunnel_id = tunnel_id.strip()
        if not re.fullmatch(r"tunnel_[a-zA-Z0-9_-]{20,}", tunnel_id):
            QMessageBox.warning(None, "Erzhan PC", "Invalid tunnel ID. It must start with tunnel_.")
            return
        api_key, ok = QInputDialog.getText(None, "Runtime API key", "Paste the restricted Tunnels Read + Use key:", QLineEdit.Password)
        if not ok or not api_key.strip():
            return
        profile = "erzhan-" + re.sub(r"[^a-z0-9-]", "-", socket.gethostname().lower())[:30]
        env = os.environ.copy()
        env["CONTROL_PLANE_API_KEY"] = api_key.strip()
        env.update(runtime_auth_headers(self.local_token))
        existing = current.get("profile") == profile and current.get("tunnel_id") == tunnel_id
        if not existing:
            process = subprocess.run(
                [path, "init", "--sample", "sample_mcp_remote_no_auth", "--profile", profile,
                 "--tunnel-id", tunnel_id, "--mcp-server-url", "http://127.0.0.1:8787/mcp"],
                env=env, capture_output=True, text=True, timeout=40,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if process.returncode:
                QMessageBox.warning(None, "Tunnel configuration failed", process.stderr[-900:] or process.stdout[-900:])
                return
        save_api_key(api_key)
        target = settings_path().with_name("tunnel.json")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps({"path": path, "profile": profile, "tunnel_id": tunnel_id}, indent=2), encoding="utf-8")
        self.close_tunnel()
        if self.broker.enabled:
            self.server_wait_attempts = 0
            self.start_tunnel()
        QMessageBox.information(None, "Erzhan PC", "Tunnel configured. Press Start access to connect this PC.")

    def start_tunnel(self):
        if not self.broker.enabled:
            self.last_activity = "Access paused; tunnel stopped"
            return
        if self.tunnel_process is not None and self.tunnel_process.poll() is None:
            return
        try:
            with socket.create_connection(("127.0.0.1", 8787), timeout=0.2):
                self.server_wait_attempts = 0
        except OSError:
            self.server_wait_attempts += 1
            if self.server_wait_attempts <= 40:
                self.last_activity = "Waiting for local MCP server"
                QTimer.singleShot(300, self.start_tunnel)
            else:
                self.last_activity = "Local MCP unavailable; check server-error.log"
            return
        data = self.tunnel_settings()
        executable = data.get("path")
        profile = data.get("profile")
        if not executable or not profile or not Path(executable).is_file():
            self.last_activity = "Tunnel setup needed"
            return
        env = os.environ.copy()
        env.update(runtime_auth_headers(self.local_token))
        try:
            key = read_api_key()
        except Exception:
            self.last_activity = "Unable to unlock runtime API key"
            return
        if key:
            env["CONTROL_PLANE_API_KEY"] = key
        if "CONTROL_PLANE_API_KEY" not in env:
            self.last_activity = "Runtime API key missing"
            return
        try:
            path = settings_path().with_name("tunnel.log")
            path.parent.mkdir(parents=True, exist_ok=True)
            self.tunnel_health_file.unlink(missing_ok=True)
            self.tunnel_log = path.open("ab")
            self.tunnel_process = subprocess.Popen(
                tunnel_command(executable, profile, self.tunnel_health_file),
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=self.tunnel_log,
                stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            self.last_activity = "Tunnel launched; waiting for readiness"
        except OSError as error:
            self.last_activity = f"Tunnel failed: {error}"

    def close_tunnel(self):
        if self.tunnel_process is not None and self.tunnel_process.poll() is None:
            self.tunnel_process.terminate()
            try:
                self.tunnel_process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.tunnel_process.kill()
                self.tunnel_process.wait(timeout=3)
        self.tunnel_process = None
        self.tunnel_health_file.unlink(missing_ok=True)
        if self.tunnel_log:
            self.tunnel_log.close()
            self.tunnel_log = None

    def make_icon(self):
        return brand_icon()

    def ask_user(self, capability, detail):
        done = threading.Event()
        response = {"choice": "deny", "done": done}
        self.signals.ask.emit(capability, detail, response)
        done.wait(timeout=45)
        return response["choice"]

    def show_approval(self, capability, detail, response):
        try:
            dialog = PermissionDialog(capability, detail, self.broker.allow_shortcut)
            self.active_dialog = dialog
            dialog.exec()
            response["choice"] = dialog.choice
        finally:
            self.active_dialog = None
            response["done"].set()

    def approve_pending(self):
        if self.active_dialog and self.active_dialog.isVisible():
            self.active_dialog.set_choice("once")

    def save_approval_hotkey(self, shortcut):
        self.broker.set_allow_shortcut(shortcut)
        self.hotkey.shortcut = shortcut
        self.hotkey.start()

    def start_automation(self, profile):
        if profile == "crazy":
            warning = ("This allows EVERY connected request for up to 2 minutes, including deletion, "
                       "downloads, shell commands, and shutdown. Access may be irreversibly changed.\n\n"
                       "Type CRAZY to enable temporarily:")
            answer, accepted = QInputDialog.getText(None, "Unrestricted control", warning)
            if not accepted or answer != "CRAZY":
                return
        else:
            answer = QMessageBox.question(None, "Risk mode",
                "Approve mouse and keyboard input for up to 15 minutes? File writes, shell, downloads, "
                "cloud uploads, and other powerful operations still require confirmation.",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                return
        try:
            self.broker.grant_automation(profile, 120 if profile == "crazy" else 900)
        except PermissionError as error:
            QMessageBox.warning(None, "Automation unavailable", str(error))
            return
        self.hud.show()
        self.hud.raise_()
        self.hud.refresh()
        if self.dashboard:
            self.dashboard.refresh_status()

    def stop_automation(self):
        self.broker.stop_automation()
        self.hud.refresh()
        if self.dashboard:
            self.dashboard.refresh_status()

    def activity(self, capability):
        self.signals.activity.emit(capability)

    def record_activity(self, capability):
        self.last_activity = f"{datetime.now().strftime('%H:%M:%S')} | {CAPABILITIES.get(capability, capability)}"

    def refresh(self):
        status = self.broker.status()
        self.toggle.setText("Stop access" if status["enabled"] else "Start access")
        self.private_action.setCheckable(True)
        self.full_action.setCheckable(True)
        self.private_action.setChecked(status["mode"] == "private")
        self.full_action.setChecked(status["mode"] == "full")

    def toggle_access(self):
        self.set_access(not self.broker.enabled)

    def set_access(self, enabled):
        self.broker.set_enabled(enabled)
        if enabled:
            self.server_wait_attempts = 0
            self.start_tunnel()
        else:
            self.close_tunnel()
            self.last_activity = "Access paused; tunnel stopped"
        self.refresh()

    def change_mode(self, mode):
        if mode == "full" and self.broker.mode != "full":
            result = QMessageBox.question(None, "Enable full access?",
                "Full mode lets connected ChatGPT tools see the screen and read files.\n"
                "PowerShell, file changes and UI input still require local approval.\n"
                "Continue?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if result != QMessageBox.Yes:
                return
        self.broker.set_mode(mode)
        self.refresh()
        if self.dashboard:
            self.dashboard.refresh_status()

    def grant_input_lease(self):
        try:
            self.broker.grant_input_lease(300)
        except PermissionError as error:
            QMessageBox.information(None, "Erzhan PC", str(error))
            return
        self.tray.showMessage("Erzhan PC", "UI control is active for 5 minutes, including potentially sensitive actions. Pause access to stop new requests.", QSystemTrayIcon.Warning, 4000)
        if self.dashboard:
            self.dashboard.refresh_status()

    def show_status(self):
        if self.dashboard is None:
            self.dashboard = Dashboard(self)
        self.dashboard.refresh_status()
        self.dashboard.show()
        self.dashboard.raise_()
        self.dashboard.activateWindow()

    def on_tray_activation(self, reason):
        if reason == QSystemTrayIcon.DoubleClick:
            self.show_status()


def main():
    if os.name != "nt":
        raise SystemExit("Erzhan PC requires Windows")
    if "--wait-for" in sys.argv:
        try:
            index = sys.argv.index("--wait-for")
            parent = int(sys.argv[index + 1])
            kernel = ctypes.windll.kernel32
            kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel.OpenProcess.restype = wintypes.HANDLE
            kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            handle = kernel.OpenProcess(0x00100000, 0, parent)
            if handle:
                kernel.WaitForSingleObject(handle, 15000)
                kernel.CloseHandle(handle)
        except (ValueError, IndexError):
            pass
    app = QApplication(sys.argv)
    app.setWindowIcon(brand_icon())
    app.setQuitOnLastWindowClosed(False)
    try:
        with socket.create_connection(("127.0.0.1", 8787), timeout=0.2):
            QMessageBox.critical(None, "Erzhan PC",
                "Port 8787 is already in use. Close the older Erzhan PC instance or its local MCP server before starting this version.")
            return 2
    except OSError:
        pass
    if not QSystemTrayIcon.isSystemTrayAvailable():
        QMessageBox.critical(None, "Erzhan PC", "Windows notification area is unavailable")
        return 1
    tray = TrayApp(app)
    if "--show" in sys.argv:
        tray.show_status()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
