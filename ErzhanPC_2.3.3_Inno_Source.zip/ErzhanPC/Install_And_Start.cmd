@echo off
setlocal
cd /d "%~dp0"
if not exist "dist\ErzhanPC.exe" (
    call "Build_Windows.cmd"
    if errorlevel 1 (
        pause
        exit /b 1
    )
)
start "" "dist\ErzhanPC.exe"
exit /b 0
