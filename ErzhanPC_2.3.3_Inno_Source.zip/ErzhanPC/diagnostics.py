def classify_tunnel_problem(output):
    message = str(output).lower()
    if "401" in message or "invalid api key" in message or "unauthenticated" in message:
        return "Runtime API key is missing, expired, or rejected"
    if "403" in message or "permission denied" in message or "forbidden" in message:
        return "Tunnel permissions or organization access are insufficient"
    if "connection refused" in message:
        return "The local MCP server is not reachable"
    if "no such profile" in message or "profile not found" in message:
        return "The tunnel profile is missing; configure it again"
    if "timed out" in message or "timeout" in message or "dns" in message:
        return "Network or proxy could not reach the OpenAI tunnel service"
    if "certificate" in message or "tls" in message:
        return "TLS or proxy certificate validation failed"
    return "Unknown cause; check tunnel.log for details"
