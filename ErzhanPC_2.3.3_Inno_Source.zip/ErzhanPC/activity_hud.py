from PySide6.QtCore import Qt, QPoint, QTimer
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from ui_icons import icon


class ActivityHud(QWidget):
    def __init__(self, tray):
        super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.tray = tray
        self.drag_anchor = None
        self.user_moved = False
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setFixedWidth(326)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        panel = QFrame()
        panel.setObjectName("hud")
        panel.setStyleSheet("""
            QFrame#hud { background: #111d2c; border: 1px solid #34485f; border-radius: 18px; }
            QLabel { color: #e6ecf5; background: transparent; font: 10pt 'Segoe UI'; }
            QLabel#muted { color: #9baec5; }
            QPushButton { background: #273b53; border: 1px solid #34485f; border-radius: 8px;
                          color: white; min-height: 26px; padding: 3px 8px; }
            QPushButton#stop { background: #7d2838; border: 1px solid #ba5061; }
        """)
        root.addWidget(panel)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(14, 12, 14, 12)
        heading = QHBoxLayout()
        badge = QLabel("ERZHAN PC  •  LIVE")
        heading.addWidget(badge)
        heading.addStretch()
        hide = QPushButton()
        hide.setIcon(icon("x", size=16))
        hide.setToolTip("Hide activity panel")
        hide.setFixedWidth(35)
        hide.clicked.connect(self.hide)
        heading.addWidget(hide)
        layout.addLayout(heading)
        self.activity = QLabel("Waiting for requests")
        self.activity.setWordWrap(True)
        self.activity.setObjectName("muted")
        layout.addWidget(self.activity)
        self.mode = QLabel("Manual approval")
        self.mode.setObjectName("muted")
        layout.addWidget(self.mode)
        buttons = QHBoxLayout()
        self.stop_button = QPushButton("Stop auto-approval")
        self.stop_button.setObjectName("stop")
        self.stop_button.setIcon(icon("shield-check", size=18))
        self.stop_button.clicked.connect(self.tray.stop_automation)
        buttons.addWidget(self.stop_button)
        open_button = QPushButton()
        open_button.setIcon(icon("settings", size=18))
        open_button.setToolTip("Open control center")
        open_button.clicked.connect(self.tray.show_status)
        buttons.addWidget(open_button)
        layout.addLayout(buttons)
        timer = QTimer(self)
        timer.timeout.connect(self.refresh)
        timer.start(1000)
        self.refresh()

    def refresh(self):
        status = self.tray.broker.status()
        self.activity.setText(self.tray.last_activity)
        mode = status["automation_profile"]
        seconds = status["automation_seconds"]
        self.mode.setText(f"{mode.upper()}  •  {seconds}s remaining" if seconds else
                          "Manual approvals  •  agent connected" if status["enabled"] else "Access paused")
        self.stop_button.setEnabled(bool(seconds))
        if not self.user_moved and self.isVisible():
            self.position_corner()

    def position_corner(self):
        screen = QApplication.primaryScreen()
        if screen:
            geometry = screen.availableGeometry()
            self.move(geometry.right() - self.width() - 22, geometry.bottom() - self.height() - 22)

    def showEvent(self, event):
        super().showEvent(event)
        if not self.user_moved:
            QTimer.singleShot(0, self.position_corner)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_anchor = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self.drag_anchor is not None and event.buttons() & Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_anchor)
            self.user_moved = True
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self.drag_anchor = None
        super().mouseReleaseEvent(event)
