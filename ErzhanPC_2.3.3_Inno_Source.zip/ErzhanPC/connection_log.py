import logging
from logging.handlers import RotatingFileHandler

from approval import settings_path


class ReopenRotatingFileHandler(RotatingFileHandler):
    def emit(self, record):
        try:
            super().emit(record)
        finally:
            self.close()


def log_path():
    return settings_path().with_name("logs") / "connection.log"


def get_logger():
    logger = logging.getLogger("erzhanpc.connection")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    try:
        path = log_path()
        for current in list(logger.handlers):
            if isinstance(current, RotatingFileHandler) and current.baseFilename == str(path):
                return logger
            current.close()
            logger.removeHandler(current)
        path.parent.mkdir(parents=True, exist_ok=True)
        handler = ReopenRotatingFileHandler(path, maxBytes=2_000_000, backupCount=3, encoding="utf-8", delay=True)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
    except OSError:
        logger.addHandler(logging.NullHandler())
    return logger
