import os
import secrets
import traceback
from datetime import datetime, timezone
from pathlib import Path

from connection_log import get_logger


class LocalTokenMiddleware:
    def __init__(self, app, token):
        self.app = app
        self.token = token.encode("ascii")

    async def __call__(self, scope, receive, send):
        if scope["type"] in {"http", "websocket"}:
            supplied = next(
                (value for name, value in scope.get("headers", []) if name.lower() == b"x-erzhan-local-auth"),
                b"",
            )
            if not secrets.compare_digest(supplied, self.token):
                get_logger().warning("Local MCP request rejected: missing or invalid tunnel authentication header")
                if scope["type"] == "http":
                    body = b"Unauthorized"
                    await send({"type": "http.response.start", "status": 401, "headers": [
                        (b"content-type", b"text/plain"), (b"content-length", str(len(body)).encode("ascii"))
                    ]})
                    await send({"type": "http.response.body", "body": body})
                else:
                    await send({"type": "websocket.close", "code": 1008})
                return
        await self.app(scope, receive, send)


def create_local_token():
    return secrets.token_urlsafe(36)


def run_secured(server, token, port):
    try:
        import uvicorn

        app = LocalTokenMiddleware(server.streamable_http_app(), token)
        get_logger().info("Local MCP listening on 127.0.0.1:%s", port)
        uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning", access_log=False,
                    http="h11", loop="asyncio", ws="none", lifespan="on", log_config=None)
    except Exception:
        get_logger().exception("Local MCP server stopped unexpectedly")
        directory = Path(os.environ.get("APPDATA") or Path.home()) / "ErzhanPC"
        directory.mkdir(parents=True, exist_ok=True)
        with (directory / "server-error.log").open("a", encoding="utf-8") as error_log:
            error_log.write(datetime.now(timezone.utc).isoformat() + "\n" + traceback.format_exc() + "\n")
