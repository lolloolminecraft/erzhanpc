import io
import os
import subprocess
from pathlib import Path

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff"}
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".mov", ".avi", ".wmv", ".webm", ".m4v", ".mpeg", ".mpg"}


def media_path(path, extensions):
    target = Path(os.path.expandvars(path)).expanduser().resolve(strict=True)
    if not target.is_file() or target.suffix.lower() not in extensions:
        raise ValueError("Unsupported media file")
    return target


def image_preview(path, max_dimension=1400):
    from PIL import Image, ImageOps

    target = media_path(path, IMAGE_EXTENSIONS)
    limit = max(320, min(int(max_dimension), 2048))
    with Image.open(target) as source:
        if source.width * source.height > 60000000:
            raise ValueError("Image exceeds supported pixel limit")
        image = ImageOps.exif_transpose(source).convert("RGB")
        image.thumbnail((limit, limit), Image.Resampling.LANCZOS)
        output = io.BytesIO()
        image.save(output, format="JPEG", quality=85)
    return output.getvalue()


def video_info(path):
    target = media_path(path, VIDEO_EXTENSIONS)
    import imageio_ffmpeg

    frames = imageio_ffmpeg.read_frames(str(target))
    try:
        metadata = next(frames)
    finally:
        frames.close()
    width, height = metadata.get("size", (0, 0))
    return {
        "path": str(target),
        "duration_seconds": float(metadata.get("duration") or 0),
        "fps": float(metadata.get("fps") or 0),
        "width": int(width),
        "height": int(height),
        "codec": str(metadata.get("codec") or "unknown"),
    }


def video_frame(path, second=0, width=960):
    target = media_path(path, VIDEO_EXTENSIONS)
    position = float(second)
    if not 0 <= position <= 86400:
        raise ValueError("Timestamp must be between 0 and 86400 seconds")
    import imageio_ffmpeg

    size = max(320, min(int(width), 1280))
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run(
        [imageio_ffmpeg.get_ffmpeg_exe(), "-nostdin", "-hide_banner", "-loglevel", "error",
         "-ss", f"{position:.3f}", "-i", str(target), "-an", "-frames:v", "1",
         "-vf", f"scale={size}:-2", "-f", "image2pipe", "-vcodec", "mjpeg", "pipe:1"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=25,
        creationflags=flags,
    )
    if result.returncode or not result.stdout:
        raise RuntimeError("Could not decode a frame at this timestamp")
    if len(result.stdout) > 8000000:
        raise ValueError("Decoded frame exceeded size limit")
    return result.stdout


def video_contact_sheet(path, frame_count=6):
    from PIL import Image, ImageDraw

    details = video_info(path)
    duration = details["duration_seconds"]
    if duration <= 0:
        raise ValueError("Video duration unavailable; request an individual frame")
    count = max(2, min(int(frame_count), 9))
    columns = 3
    cell_width, cell_height = 480, 290
    rows = (count + columns - 1) // columns
    sheet = Image.new("RGB", (columns * cell_width, rows * cell_height), "#202020")
    draw = ImageDraw.Draw(sheet)
    rendered = 0
    for index in range(count):
        timestamp = duration * (index + 0.5) / count
        try:
            image = Image.open(io.BytesIO(video_frame(path, timestamp, width=480))).convert("RGB")
        except (OSError, RuntimeError, ValueError):
            continue
        image.thumbnail((cell_width, 260), Image.Resampling.LANCZOS)
        left = (index % columns) * cell_width
        top = (index // columns) * cell_height
        sheet.paste(image, (left, top))
        draw.text((left + 8, top + 265), f"{timestamp:.1f}s", fill="white")
        rendered += 1
    if not rendered:
        raise RuntimeError("No video frames could be decoded")
    output = io.BytesIO()
    sheet.save(output, format="JPEG", quality=82)
    return output.getvalue()
