import sys
import zipfile
from functools import lru_cache
from pathlib import Path

from PySide6.QtCore import QByteArray, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer


@lru_cache(maxsize=128)
def icon(name, color="#dce5f2", size=24):
    path = Path(getattr(sys, "_MEIPASS", Path(__file__).parent)) / "icons" / (name + ".svg")
    try:
        source = None
        try:
            import update_engine
            patch = update_engine.active_patch_path()
            if patch:
                with zipfile.ZipFile(patch) as archive:
                    if "icons/" + name + ".svg" in archive.namelist():
                        source = archive.read("icons/" + name + ".svg").decode("utf-8")
        except (OSError, KeyError, UnicodeDecodeError, zipfile.BadZipFile):
            source = None
        source = (source if source is not None else path.read_text(encoding="utf-8")).replace("currentColor", color)
        renderer = QSvgRenderer(QByteArray(source.encode("utf-8")))
        if not renderer.isValid():
            raise ValueError("Invalid SVG")
        pixels = QPixmap(size, size)
        pixels.fill(Qt.transparent)
        painter = QPainter(pixels)
        renderer.render(painter)
        painter.end()
        return QIcon(pixels)
    except (OSError, ValueError):
        pixels = QPixmap(size, size)
        pixels.fill(QColor("#22364c"))
        return QIcon(pixels)


def action_button(text, image, callback, parent=None):
    from PySide6.QtWidgets import QPushButton

    button = QPushButton(text, parent)
    button.setIcon(icon(image))
    button.clicked.connect(callback)
    return button


def brand_icon():
    path = Path(getattr(sys, "_MEIPASS", Path(__file__).parent)) / "icons" / "ErzhanPC.ico"
    if path.is_file():
        return QIcon(str(path))
    return icon("monitor", "#75baff", 64)
