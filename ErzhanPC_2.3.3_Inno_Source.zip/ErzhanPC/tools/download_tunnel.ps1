param(
    [Parameter(Mandatory = $true)][string]$Destination,
    [string]$CacheDirectory = "$env:LOCALAPPDATA\ErzhanPC\InstallerCache"
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
New-Item -ItemType Directory -Path $Destination -Force | Out-Null
New-Item -ItemType Directory -Path $CacheDirectory -Force | Out-Null
$release = Invoke-RestMethod -Uri 'https://api.github.com/repos/openai/tunnel-client/releases/latest' -Headers @{ 'User-Agent' = 'ErzhanPC-Builder' }
$asset = @($release.assets | Where-Object { $_.name -match '^tunnel-client-v[0-9].*-windows-amd64\.zip$' }) | Select-Object -First 1
if (-not $asset) {
    throw 'The official Windows tunnel-client release was not found.'
}
if (-not $asset.digest -or $asset.digest -notmatch '^sha256:[0-9a-fA-F]{64}$') {
    throw 'The official release has no SHA-256 digest.'
}
$archive = Join-Path $CacheDirectory $asset.name
$expected = $asset.digest.Substring(7).ToLowerInvariant()
$cached = (Test-Path -LiteralPath $archive) -and ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -eq $expected)
if (-not $cached) {
    $temporary = $archive + '.partial'
    $client = [System.Net.Http.HttpClient]::new()
    $client.Timeout = [TimeSpan]::FromMinutes(30)
    $client.DefaultRequestHeaders.UserAgent.ParseAdd('ErzhanPC-Builder/2.3.3')
    try {
        $response = $client.GetAsync($asset.browser_download_url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        $response.EnsureSuccessStatusCode() | Out-Null
        $expectedBytes = $response.Content.Headers.ContentLength
        $inputStream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $outputStream = [IO.File]::Open($temporary, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try {
            $buffer = New-Object byte[] (1024 * 1024)
            $received = [long]0
            while (($count = $inputStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
                $outputStream.Write($buffer, 0, $count)
                $received += $count
                if ($expectedBytes -and $expectedBytes -gt 0) {
                    $percentage = [Math]::Min(99, [int][Math]::Floor(100.0 * $received / $expectedBytes))
                    Write-Progress -Activity 'Downloading official tunnel-client' -Status "$percentage% ($([Math]::Round($received / 1MB, 1)) MB)" -PercentComplete $percentage
                } else {
                    Write-Progress -Activity 'Downloading official tunnel-client' -Status "$([Math]::Round($received / 1MB, 1)) MB downloaded"
                }
            }
        } finally {
            $outputStream.Dispose()
            $inputStream.Dispose()
            $response.Dispose()
        }
        Write-Progress -Activity 'Downloading official tunnel-client' -Completed
        $digest = (Get-FileHash -LiteralPath $temporary -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($digest -ne $expected) {
            throw 'The downloaded tunnel-client checksum does not match the official release.'
        }
        Move-Item -LiteralPath $temporary -Destination $archive -Force
    } finally {
        $client.Dispose()
        if (Test-Path -LiteralPath $temporary) {
            Remove-Item -LiteralPath $temporary -Force
        }
    }
}
$unpack = Join-Path $CacheDirectory ($asset.name + '.unpacked')
Expand-Archive -LiteralPath $archive -DestinationPath $unpack -Force
$source = Get-ChildItem -LiteralPath $unpack -Filter 'tunnel-client.exe' -Recurse -File | Select-Object -First 1
if (-not $source) {
    throw 'Verified archive does not contain tunnel-client.exe.'
}
Copy-Item -LiteralPath $source.FullName -Destination (Join-Path $Destination 'tunnel-client.exe') -Force
Write-Output ('Bundled official tunnel-client ' + $release.tag_name + $(if ($cached) { ' (verified cache)' } else { ' (download verified)' }))
