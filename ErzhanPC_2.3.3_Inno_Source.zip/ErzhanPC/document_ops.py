import errno
import hashlib
import json
import os
import secrets
import shutil
from datetime import datetime, timezone
from pathlib import Path


TEXT_EXTENSIONS = {".txt", ".md", ".csv", ".json", ".yaml", ".yml", ".xml", ".ini", ".cfg", ".py", ".js", ".ts", ".css", ".html"}
DOCUMENT_EXTENSIONS = {".doc", ".docx", ".xls", ".xlsx", ".csv", ".ppt", ".pptx", ".pdf", ".txt", ".rtf", ".odt", ".ods", ".odp"}
FOLDER_GROUPS = {
    "Images": {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff", ".heic"},
    "Videos": {".mp4", ".mkv", ".mov", ".avi", ".wmv", ".webm", ".m4v", ".mpeg", ".mpg"},
    "Audio": {".mp3", ".wav", ".flac", ".aac", ".m4a", ".ogg"},
    "Documents": DOCUMENT_EXTENSIONS | {".md", ".json", ".xml"},
    "Archives": {".zip", ".rar", ".7z", ".tar", ".gz"},
    "Installers": {".exe", ".msi", ".msix"},
}


def text_replace(path, old_text, new_text, replace_all=False, expected_sha256=None):
    target = Path(os.path.expandvars(path)).expanduser().resolve(strict=True)
    if not target.is_file() or target.suffix.lower() not in TEXT_EXTENSIONS:
        raise ValueError("Only supported text files can be edited directly")
    if not old_text:
        raise ValueError("Search text must not be empty")
    if target.stat().st_size > 8000000:
        raise ValueError("Text file exceeds 8 MB limit")
    original = target.read_bytes()
    digest = hashlib.sha256(original).hexdigest()
    if expected_sha256 and expected_sha256.lower() != digest:
        raise ValueError("File changed since it was inspected")
    content = original.decode("utf-8-sig")
    count = content.count(old_text)
    if count < 1:
        raise ValueError("Search text was not found")
    if count > 1 and not replace_all:
        raise ValueError(f"Search text has {count} matches; explicit replace_all is required")
    updated = content.replace(old_text, new_text, -1 if replace_all else 1)
    bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    payload = bom + updated.encode("utf-8")
    suffix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(3)
    backup = target.with_name(f"{target.name}.backup-{suffix}")
    temporary = target.with_name(f"{target.name}.pending-{suffix}")
    shutil.copy2(target, backup)
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        shutil.copymode(target, temporary)
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return {"path": str(target), "backup": str(backup), "replacements": count if replace_all else 1, "previous_sha256": digest}


def move_file(source, destination):
    original = Path(os.path.expandvars(source)).expanduser().resolve(strict=True)
    target = Path(os.path.expandvars(destination)).expanduser()
    if not original.is_file():
        raise ValueError("Only individual files can be moved")
    if target.exists():
        raise FileExistsError(str(target))
    if not target.is_absolute():
        raise ValueError("Destination must be an absolute path")
    if not target.parent.is_dir():
        raise FileNotFoundError(str(target.parent))
    try:
        original.rename(target)
    except OSError as error:
        if error.errno != errno.EXDEV:
            raise
        temporary = target.with_name(f"{target.name}.pending-{secrets.token_hex(8)}")
        try:
            with original.open("rb") as reader, temporary.open("xb") as writer:
                shutil.copyfileobj(reader, writer, length=1024 * 1024)
                writer.flush()
                os.fsync(writer.fileno())
            shutil.copystat(original, temporary)
            if file_hash(str(original))["sha256"] != file_hash(str(temporary))["sha256"]:
                raise IOError("Copied file verification failed")
            if target.exists():
                raise FileExistsError(str(target))
            temporary.rename(target)
            original.unlink()
        finally:
            temporary.unlink(missing_ok=True)
    return {"old_path": str(original), "new_path": str(target)}


def file_hash(path):
    target = Path(os.path.expandvars(path)).expanduser().resolve(strict=True)
    if not target.is_file():
        raise ValueError("Only individual files can be hashed")
    digest = hashlib.sha256()
    with target.open("rb") as reader:
        for block in iter(lambda: reader.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": str(target), "bytes": target.stat().st_size, "sha256": digest.hexdigest()}


def folder_inventory(path, limit=500):
    root = Path(os.path.expandvars(path)).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise NotADirectoryError(str(root))
    count = max(1, min(int(limit), 2000))
    from fast_inventory import native_inventory

    accelerated = native_inventory(root, count)
    if accelerated is not None:
        return accelerated
    items = []
    truncated = False
    for child in root.rglob("*"):
        if child.is_symlink() or not child.is_file():
            continue
        try:
            stat = child.stat()
        except OSError:
            continue
        if len(items) >= count:
            truncated = True
            break
        items.append({"path": str(child), "bytes": stat.st_size, "extension": child.suffix.lower()})
    items.sort(key=lambda item: item["bytes"], reverse=True)
    return {"directory": str(root), "scanned_files": len(items), "truncated": truncated,
            "total_bytes_scanned": sum(item["bytes"] for item in items), "files_by_size": items}


def open_document(path):
    target = Path(os.path.expandvars(path)).expanduser().resolve(strict=True)
    if not target.is_file() or target.suffix.lower() not in DOCUMENT_EXTENSIONS:
        raise ValueError("Unsupported document type")
    if os.name != "nt":
        raise RuntimeError("Opening documents requires Windows")
    os.startfile(str(target))
    return {"opened": str(target), "application": "Windows file association"}


def organization_plan(path, limit=200):
    root = Path(os.path.expandvars(path)).expanduser().resolve(strict=True)
    if not root.is_dir() or root.parent == root:
        raise ValueError("Choose a specific folder, not a volume root")
    candidates = []
    for item in root.iterdir():
        if not item.is_file() or item.is_symlink() or item.suffix.lower() in {".tmp", ".part", ".crdownload"}:
            continue
        group = next((name for name, extensions in FOLDER_GROUPS.items() if item.suffix.lower() in extensions), "Other")
        destination = root / group / item.name
        if destination.parent.is_symlink():
            raise ValueError("Organization destination must not be a symbolic link")
        if destination.exists():
            continue
        stat = item.stat()
        candidates.append({"source": str(item), "destination": str(destination),
                           "bytes": stat.st_size, "modified_ns": stat.st_mtime_ns})
    candidates.sort(key=lambda entry: entry["source"].lower())
    batch_limit = min(max(int(limit), 1), 200)
    remaining = max(0, len(candidates) - batch_limit)
    candidates = candidates[:batch_limit]
    encoded = json.dumps(candidates, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {"directory": str(root), "plan_sha256": hashlib.sha256(encoded).hexdigest(),
            "count": len(candidates), "remaining_for_next_batch": remaining, "moves": candidates}


def organization_apply(path, expected_plan_sha256):
    plan = organization_plan(path)
    if plan["plan_sha256"] != expected_plan_sha256:
        raise ValueError("Folder changed since the organization preview; inspect it again")
    completed = []
    for move in plan["moves"]:
        destination = Path(move["destination"])
        if destination.parent.is_symlink():
            raise ValueError("Organization destination became a symbolic link")
        destination.parent.mkdir(exist_ok=True)
        move_file(move["source"], move["destination"])
        completed.append({"old_path": move["source"], "new_path": move["destination"]})
    return {"directory": plan["directory"], "moved": len(completed), "changes": completed}
