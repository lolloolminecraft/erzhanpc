import secrets
import shutil
import subprocess
import threading
import time


class PowerShellJobs:
    def __init__(self):
        self.jobs = {}
        self.lock = threading.RLock()

    def start(self, command):
        exe = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
        if not exe:
            raise RuntimeError("PowerShell not found")
        with self.lock:
            if len(self.jobs) >= 50:
                completed = sorted((item for item in self.jobs.values() if item["status"] != "running"),
                                   key=lambda item: item["started"])
                for item in completed[:len(self.jobs) - 49]:
                    self.jobs.pop(item["id"], None)
            active = sum(1 for x in self.jobs.values() if x["status"] == "running")
            if active >= 3:
                raise RuntimeError("Three PowerShell jobs are already running")
            key = secrets.token_hex(12)
            process = subprocess.Popen(
                [exe, "-NoProfile", "-NonInteractive", "-Command", command],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            job = {"id": key, "status": "running", "exit_code": None,
                   "output": "", "started": time.time(), "pid": process.pid}
            self.jobs[key] = job

        def collect():
            clock = threading.Timer(600, process.kill)
            clock.daemon = True
            clock.start()
            try:
                while True:
                    chunk = process.stdout.read(4096)
                    if not chunk:
                        break
                    with self.lock:
                        job["output"] = (job["output"] + chunk.decode("utf-8", errors="replace"))[-32000:]
                code = process.wait()
                with self.lock:
                    job["exit_code"] = code
                    job["status"] = "finished"
            except OSError:
                with self.lock:
                    job["status"] = "error"
            finally:
                clock.cancel()
                process.stdout.close()

        threading.Thread(target=collect, daemon=True).start()
        return {"job_id": key, "pid": process.pid, "status": "running"}

    def status(self, job_id):
        with self.lock:
            job = self.jobs.get(job_id)
            if job is None:
                raise KeyError("Job not found")
            return dict(job)
