use std::ffi::{c_char, CStr, CString};
use std::fmt::Write as _;
use std::fs;
use std::path::{Path, PathBuf};
use std::ptr;

struct Entry {
    path: String,
    bytes: u64,
    extension: String,
}

fn quote(value: &str) -> String {
    let mut result = String::with_capacity(value.len() + 2);
    result.push('"');
    for character in value.chars() {
        match character {
            '"' => result.push_str("\\\""),
            '\\' => result.push_str("\\\\"),
            '\n' => result.push_str("\\n"),
            '\r' => result.push_str("\\r"),
            '\t' => result.push_str("\\t"),
            character if (character as u32) < 32 => {
                let _ = write!(result, "\\u{:04x}", character as u32);
            }
            _ => result.push(character),
        }
    }
    result.push('"');
    result
}

fn scan(root: &Path, limit: usize) -> Option<String> {
    let mut directories = vec![fs::read_dir(root).ok()?];
    let mut files = Vec::with_capacity(limit);
    let mut truncated = false;
    while let Some(directory) = directories.last_mut() {
        match directory.next() {
            Some(Ok(item)) => {
                let kind = match item.file_type() {
                    Ok(value) => value,
                    Err(_) => continue,
                };
                if kind.is_symlink() {
                    continue;
                }
                if kind.is_dir() {
                    if let Ok(next) = fs::read_dir(item.path()) {
                        directories.push(next);
                    }
                    continue;
                }
                if !kind.is_file() {
                    continue;
                }
                let metadata = match item.metadata() {
                    Ok(value) => value,
                    Err(_) => continue,
                };
                let path = item.path();
                let name = match path.to_str() {
                    Some(value) => value.to_owned(),
                    None => continue,
                };
                if files.len() >= limit {
                    truncated = true;
                    break;
                }
                let extension = path.extension().and_then(|value| value.to_str())
                    .map(|value| format!(".{}", value.to_lowercase()))
                    .unwrap_or_default();
                files.push(Entry { path: name, bytes: metadata.len(), extension });
            }
            Some(Err(_)) => continue,
            None => {
                directories.pop();
            }
        }
    }
    files.sort_by(|left, right| right.bytes.cmp(&left.bytes));
    let total: u64 = files.iter().map(|entry| entry.bytes).sum();
    let mut payload = format!(
        "{{\"directory\":{},\"scanned_files\":{},\"truncated\":{},\"total_bytes_scanned\":{},\"files_by_size\":[",
        quote(&root.to_string_lossy()), files.len(), truncated, total,
    );
    for (index, item) in files.iter().enumerate() {
        if index > 0 {
            payload.push(',');
        }
        let _ = write!(payload, "{{\"path\":{},\"bytes\":{},\"extension\":{}}}",
            quote(&item.path), item.bytes, quote(&item.extension));
    }
    payload.push_str("]}");
    Some(payload)
}

#[no_mangle]
pub extern "C" fn erzhan_inventory_json(directory: *const c_char, limit: u32) -> *mut c_char {
    std::panic::catch_unwind(|| {
        if directory.is_null() {
            return ptr::null_mut();
        }
        let bytes = unsafe { CStr::from_ptr(directory) }.to_bytes();
        let value = match std::str::from_utf8(bytes) {
            Ok(value) => value,
            Err(_) => return ptr::null_mut(),
        };
        let path = PathBuf::from(value);
        let payload = match scan(&path, (limit as usize).clamp(1, 2000)) {
            Some(value) => value,
            None => return ptr::null_mut(),
        };
        CString::new(payload).map(|value| value.into_raw()).unwrap_or(ptr::null_mut())
    }).unwrap_or(ptr::null_mut())
}

#[no_mangle]
pub extern "C" fn erzhan_free_json(value: *mut c_char) {
    if value.is_null() {
        return;
    }
    let _ = std::panic::catch_unwind(|| unsafe {
        drop(CString::from_raw(value));
    });
}

#[cfg(test)]
mod tests {
    use super::quote;

    #[test]
    fn escapes_json_control_characters() {
        assert_eq!(quote("x\n\"\\\0"), "\"x\\n\\\"\\\\\\u0000\"");
    }
}
