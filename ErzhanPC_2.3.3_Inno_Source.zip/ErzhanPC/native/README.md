# Erzhan PC Native Core

The application keeps its Python/PySide6 interface and security broker. The optional Rust library speeds up recursive file metadata collection for `folder_inventory` while preserving the Python implementation as a fallback.

On a Windows machine with Rust installed, `ErzhanPC/Build_Windows.cmd` compiles `native/erzhan_core.rs` to `native/erzhan_core.dll` and bundles that DLL inside the single user-facing `ErzhanPC.exe` with PyInstaller. Without Rust, the build continues with the tested Python fallback. A separately installed official `tunnel-client.exe` remains necessary for the Secure MCP Tunnel.

Manual native build from the `ErzhanPC` directory:

```bat
rustc --edition=2021 --crate-type=cdylib -C opt-level=3 -C panic=abort --crate-name erzhan_core native\erzhan_core.rs -o native\erzhan_core.dll
```

Run the Python tests before packaging:

```bat
py -3 -m unittest discover -s tests -p test_*.py
```

This native module does not grant any additional permissions or bypass the existing approval broker. It only inventories files that the existing broker has already approved for reading. No memory or speedup percentage is claimed until the native build is benchmarked on the target Windows computer.
