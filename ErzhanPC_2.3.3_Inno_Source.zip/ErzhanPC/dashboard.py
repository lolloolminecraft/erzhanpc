import json
import os
import shutil
import socket
import subprocess
import threading
from collections import deque

from PySide6.QtCore import QEasingCurve, QObject, QPropertyAnimation, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QKeySequence
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QKeySequenceEdit,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from approval import CAPABILITIES, settings_path
from tunnel_runtime import tunnel_ready
from ui_icons import brand_icon, icon
import update_engine
import windows_ops as ops


STYLE = """
QWidget { background: #121b2a; color: #e7edf7; font-family: 'Segoe UI', 'Consolas'; font-size: 10pt; }
QWidget#surface { background: #121b2a; border: 1px solid #354962; border-radius: 17px; }
QMainWindow { background: transparent; }
QFrame#panel { background: #1d2b40; border: 1px solid #354962; border-radius: 14px; }
QLabel#muted { color: #9dadc4; }
QLabel#title { font-size: 22pt; font-weight: 700; color: #f4f8ff; }
QLabel#value { font-size: 14pt; }
QPushButton { background: #263950; color: #e7edf7; border: 1px solid #48617b; border-radius: 10px; padding: 7px 12px; min-height: 26px; }
QPushButton:hover { border: 1px solid #75baff; background: #314a67; }
QPushButton:focus { border: 1px solid #75baff; }
QPushButton:disabled { color: #667993; border-color: #304158; }
QPushButton#primary { background: #154d8b; border: 1px solid #4f9bf1; }
QPushButton#danger { background: #692e41; border: 1px solid #e26b84; }
QPushButton#windowButton { background: transparent; border: 0; min-height: 20px; }
QTabWidget::pane { border: 1px solid #354962; border-radius: 10px; }
QTabBar::tab { background: #17263a; color: #9dadc4; padding: 10px 11px; margin-right: 5px; border: 1px solid #354962; border-top-left-radius: 9px; border-top-right-radius: 9px; }
QTabBar::tab:selected { background: #2a405c; color: #fdfcfc; border-bottom-color: #2a405c; }
QTableWidget, QTextEdit, QKeySequenceEdit { background: #1a283c; border: 1px solid #354962; border-radius: 8px; gridline-color: #354962; selection-background-color: #2d557b; selection-color: #fdfcfc; }
QHeaderView::section { background: #253a53; color: #fdfcfc; padding: 7px; border: 1px solid #354962; }
QScrollBar:vertical { width: 10px; background: #121b2a; }
QScrollBar::handle:vertical { background: #48617b; min-height: 30px; border-radius: 5px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QToolTip { background: #263950; color: #fdfcfc; border: 1px solid #48617b; }
"""


class WindowDragBar(QFrame):
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            handle = self.window().windowHandle()
            if handle:
                handle.startSystemMove()
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        self.window().showNormal() if self.window().isMaximized() else self.window().showMaximized()
        super().mouseDoubleClickEvent(event)


class DataSignals(QObject):
    devices = Signal(object)


def panel(label, initial="--"):
    frame = QFrame()
    frame.setObjectName("panel")
    layout = QVBoxLayout(frame)
    header = QLabel(label)
    header.setObjectName("muted")
    value = QLabel(initial)
    value.setObjectName("value")
    value.setWordWrap(True)
    layout.addWidget(header)
    layout.addWidget(value)
    layout.addStretch()
    return frame, value


class Dashboard(QMainWindow):
    def __init__(self, tray):
        super().__init__()
        self.tray = tray
        self.setWindowTitle(f"Erzhan PC | {socket.gethostname()}")
        self.setWindowIcon(brand_icon())
        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(1100, 740)
        self.setMinimumSize(880, 620)
        self.setStyleSheet(STYLE)
        self.device_signals = DataSignals()
        self.device_signals.devices.connect(self.render_devices)
        container = QWidget()
        container.setObjectName("surface")
        self.setCentralWidget(container)
        root = QVBoxLayout(container)
        root.setContentsMargins(20, 12, 20, 18)
        root.setSpacing(14)

        top_bar = WindowDragBar()
        top_bar.setFixedHeight(38)
        top_row = QHBoxLayout(top_bar)
        top_row.setContentsMargins(0, 0, 0, 0)
        app_symbol = QLabel()
        app_symbol.setPixmap(brand_icon().pixmap(20, 20))
        top_row.addWidget(app_symbol)
        top_row.addWidget(QLabel(f"Erzhan PC   /   {socket.gethostname()}"))
        top_row.addStretch()
        for image, label, callback in (("minimize-2", "Minimize", self.showMinimized),
                                       ("maximize-2", "Maximize", self.toggle_maximized),
                                       ("x", "Close to tray", self.hide)):
            control = QPushButton()
            control.setObjectName("windowButton")
            control.setIcon(icon(image))
            control.setToolTip(label)
            control.setFixedSize(36, 30)
            control.clicked.connect(callback)
            top_row.addWidget(control)
        root.addWidget(top_bar)
        heading = QHBoxLayout()
        title = QVBoxLayout()
        name = QLabel("ERZHAN PC")
        name.setObjectName("title")
        subtitle = QLabel("Your computer • connected tools and permissions")
        subtitle.setObjectName("muted")
        title.addWidget(name)
        title.addWidget(subtitle)
        heading.addLayout(title)
        heading.addStretch()
        self.mode_label = QLabel("MODE: PRIVATE")
        heading.addWidget(self.mode_label)
        self.toggle_button = QPushButton("Start access")
        self.toggle_button.setIcon(icon("power"))
        self.toggle_button.setObjectName("danger")
        self.toggle_button.clicked.connect(self.toggle_access)
        heading.addWidget(self.toggle_button)
        root.addLayout(heading)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs)
        self.build_overview()
        self.build_windows()
        self.build_devices()
        self.build_security()
        self.build_connection()
        self.build_activity()
        self.build_workspace()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_status)
        self.timer.start(3000)
        self.opening_animation = QPropertyAnimation(self, b"windowOpacity", self)
        self.opening_animation.setDuration(200)
        self.opening_animation.setEasingCurve(QEasingCurve.OutCubic)
        self.refresh_status()

    def showEvent(self, event):
        super().showEvent(event)
        self.opening_animation.stop()
        self.setWindowOpacity(0.88)
        self.opening_animation.setStartValue(0.88)
        self.opening_animation.setEndValue(1.0)
        self.opening_animation.start()

    def toggle_maximized(self):
        self.showNormal() if self.isMaximized() else self.showMaximized()

    def text_line(self, layout, text, muted=True):
        label = QLabel(text)
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
        if muted:
            label.setObjectName("muted")
        layout.addWidget(label)
        return label

    def build_overview(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(16, 16, 16, 16)
        cards = QGridLayout()
        a, self.access_value = panel("ACCESS", "PAUSED")
        b, self.server_value = panel("LOCAL MCP", "CHECKING")
        c, self.tunnel_value = panel("OPENAI TUNNEL", "CHECKING")
        d, self.activity_value = panel("LAST ACTION", "NONE")
        for index, frame in enumerate((a, b, c, d)):
            cards.addWidget(frame, index // 2, index % 2)
        layout.addLayout(cards)
        self.text_line(layout, "[-] Private mode: no screen, window, device, shell or file access. Input requires approval.")
        self.text_line(layout, "[+] Full mode: observations are enabled; input, shell commands and file changes require approval.")
        buttons = QHBoxLayout()
        private = QPushButton("Private")
        private.setIcon(icon("lock-keyhole"))
        private.clicked.connect(lambda: self.set_mode("private"))
        full = QPushButton("Full")
        full.setIcon(icon("eye"))
        full.setObjectName("primary")
        full.clicked.connect(lambda: self.set_mode("full"))
        refresh = QPushButton("Refresh")
        refresh.setIcon(icon("refresh-cw"))
        refresh.clicked.connect(self.refresh_status)
        lease = QPushButton("UI input 5 min")
        lease.setIcon(icon("keyboard"))
        lease.clicked.connect(self.tray.grant_input_lease)
        buttons.addWidget(private)
        buttons.addWidget(full)
        buttons.addWidget(lease)
        buttons.addWidget(refresh)
        buttons.addStretch()
        layout.addLayout(buttons)
        layout.addStretch()
        self.tabs.addTab(page, icon("house"), "Overview")

    def build_windows(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        actions = QHBoxLayout()
        refresh = QPushButton("Refresh windows")
        refresh.setIcon(icon("refresh-cw"))
        refresh.clicked.connect(self.load_windows)
        inspect = QPushButton("Inspect structure")
        inspect.setIcon(icon("eye"))
        inspect.setObjectName("primary")
        inspect.clicked.connect(self.inspect_selected)
        actions.addWidget(refresh)
        actions.addWidget(inspect)
        actions.addStretch()
        layout.addLayout(actions)
        self.windows_table = QTableWidget(0, 3)
        self.windows_table.setHorizontalHeaderLabels(["Window", "Class", "Handle"])
        self.windows_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.windows_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.windows_table, 3)
        self.structure_text = QTextEdit()
        self.structure_text.setReadOnly(True)
        self.structure_text.setPlaceholderText("[+] Select a window to inspect its UI Automation structure")
        layout.addWidget(self.structure_text, 2)
        self.tabs.addTab(page, icon("app-window"), "Windows")

    def build_devices(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        refresh = QPushButton("List connected devices")
        refresh.setIcon(icon("refresh-cw"))
        refresh.clicked.connect(self.load_devices)
        layout.addWidget(refresh)
        self.devices_table = QTableWidget(0, 3)
        self.devices_table.setHorizontalHeaderLabels(["Device", "Category", "State"])
        self.devices_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.devices_table)
        self.tabs.addTab(page, icon("hard-drive"), "Devices")

    def build_security(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(18, 20, 18, 16)
        self.text_line(layout, "Manual / Risk / Crazy  •  automation modes always expire and never survive restart.", False)
        self.automation_status = QLabel("Manual approvals")
        layout.addWidget(self.automation_status)
        modes = QHBoxLayout()
        risk = QPushButton("Risk • 15 min")
        risk.setIcon(icon("shield-check", "#b4e6be"))
        risk.clicked.connect(lambda: self.tray.start_automation("risk"))
        crazy = QPushButton("Crazy • 2 min")
        crazy.setObjectName("danger")
        crazy.setIcon(icon("zap", "#ffb2b2"))
        crazy.clicked.connect(lambda: self.tray.start_automation("crazy"))
        stop_auto = QPushButton("Stop auto")
        stop_auto.setIcon(icon("power"))
        stop_auto.clicked.connect(self.tray.stop_automation)
        modes.addWidget(risk)
        modes.addWidget(crazy)
        modes.addWidget(stop_auto)
        modes.addStretch()
        layout.addLayout(modes)
        self.text_line(layout, "Risk mode approves UI input, but a mouse click can still trigger destructive actions inside another app.")
        self.text_line(layout, "Crazy mode approves all tools, including shell, downloads, writes and deletion. Use it only for supervised work.")
        layout.addSpacing(12)
        self.text_line(layout, "Global approval hotkey  •  works while another application is focused", False)
        hotkeys = QHBoxLayout()
        self.shortcut_input = QKeySequenceEdit()
        self.shortcut_input.setKeySequence(QKeySequence(self.tray.broker.allow_shortcut))
        self.shortcut_input.setMaximumSequenceLength(1)
        hotkeys.addWidget(self.shortcut_input, 2)
        save_hotkey = QPushButton("Save hotkey")
        save_hotkey.setIcon(icon("check"))
        save_hotkey.clicked.connect(self.store_hotkey)
        hotkeys.addWidget(save_hotkey)
        hotkeys.addStretch()
        layout.addLayout(hotkeys)
        self.text_line(layout, "Access pauses on restart. Every request is logged without the sensitive request body.")
        self.text_line(layout, "Tunnel identity is not proof of an individual user. Keep the runtime key private.")
        row = QHBoxLayout()
        stop = QPushButton("STOP ALL ACCESS")
        stop.setObjectName("danger")
        stop.setIcon(icon("power"))
        stop.clicked.connect(self.stop_all)
        row.addWidget(stop)
        activity = QPushButton("View activity")
        activity.setIcon(icon("activity"))
        activity.clicked.connect(lambda: self.tabs.setCurrentIndex(self.activity_tab))
        row.addWidget(activity)
        row.addStretch()
        layout.addLayout(row)
        layout.addStretch()
        self.tabs.addTab(page, icon("shield-check"), "Security")

    def store_hotkey(self):
        shortcut = self.shortcut_input.keySequence().toString(QKeySequence.PortableText)
        try:
            self.tray.save_approval_hotkey(shortcut)
        except ValueError as error:
            QMessageBox.warning(self, "Invalid hotkey", str(error))
            return
        QMessageBox.information(self, "Approval hotkey", f"Saved: {shortcut}")

    def build_connection(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(18, 18, 18, 18)
        self.text_line(layout, "LOCAL MCP / http://127.0.0.1:8787/mcp", False)
        self.text_line(layout, "One tunnel ID and runtime key can be used on two PCs, one active PC at a time.")
        self.text_line(layout, "1. Open OpenAI Platform > Organization > Tunnels and create a tunnel.")
        self.text_line(layout, "2. Create a restricted runtime key with Tunnels Read + Use.")
        self.text_line(layout, "3. Choose the official tunnel-client and enter the tunnel ID and key locally.")
        self.text_line(layout, "4. Add a private custom MCP server in ChatGPT, using Connection: Tunnel.")
        links = QLabel('<a style="color:#007aff" href="https://platform.openai.com/settings/organization/tunnels">[ TUNNELS ]</a>  '
                       '<a style="color:#007aff" href="https://platform.openai.com/settings/organization/api-keys">[ API KEYS ]</a>  '
                       '<a style="color:#007aff" href="https://chatgpt.com/#settings/Connectors">[ CHATGPT PLUGINS ]</a>')
        links.setOpenExternalLinks(True)
        layout.addWidget(links)
        button = QPushButton("Configure secure tunnel...")
        button.setObjectName("primary")
        button.setIcon(icon("network"))
        button.clicked.connect(self.tray.configure_tunnel)
        layout.addWidget(button)
        diagnostic_row = QHBoxLayout()
        diagnose = QPushButton("Check connection")
        diagnose.setIcon(icon("activity"))
        diagnose.clicked.connect(self.tray.check_connection)
        open_logs = QPushButton("Open logs")
        open_logs.setIcon(icon("folder-open"))
        open_logs.clicked.connect(self.tray.open_diagnostics_folder)
        diagnostic_row.addWidget(diagnose)
        diagnostic_row.addWidget(open_logs)
        diagnostic_row.addStretch()
        layout.addLayout(diagnostic_row)
        self.text_line(layout, "SIGNED UPDATES / check every 6 hours, automatically download small verified patches", False)
        update_row = QHBoxLayout()
        publisher = QPushButton("Set update publisher...")
        publisher.setIcon(icon("shield-check"))
        publisher.clicked.connect(self.tray.configure_updates)
        check = QPushButton("Check for updates")
        check.setIcon(icon("refresh-cw"))
        check.clicked.connect(lambda: self.tray.check_for_updates(True))
        update_row.addWidget(publisher)
        update_row.addWidget(check)
        update_row.addStretch()
        layout.addLayout(update_row)
        speech = QPushButton("Configure speech-to-text API key...")
        speech.setIcon(icon("settings"))
        speech.clicked.connect(self.tray.configure_transcription)
        layout.addWidget(speech)
        self.update_detail = QLabel("No update feed configured")
        self.update_detail.setObjectName("muted")
        layout.addWidget(self.update_detail)
        self.connection_detail = QTextEdit()
        self.connection_detail.setReadOnly(True)
        layout.addWidget(self.connection_detail)
        self.tabs.addTab(page, icon("network"), "Connection")

    def build_activity(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        reload_button = QPushButton("Refresh activity")
        reload_button.setIcon(icon("refresh-cw"))
        reload_button.clicked.connect(self.load_activity)
        layout.addWidget(reload_button)
        self.activity_text = QTextEdit()
        self.activity_text.setReadOnly(True)
        layout.addWidget(self.activity_text)
        self.activity_tab = self.tabs.addTab(page, icon("activity"), "Activity")

    def build_workspace(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(18, 18, 18, 18)
        self.text_line(layout, "SECOND INDEPENDENT WORKSPACE", False)
        self.text_line(layout, "Windows virtual desktops share one mouse, keyboard and display; they do not isolate AI input.")
        self.text_line(layout, "Windows Sandbox offers a separate disposable Windows session on supported editions. "
                       "The current MCP agent does not control applications inside that sandbox.")
        self.text_line(layout, "For truly independent AI work and your own work, use a second Windows VM with its own agent "
                       "or a separate PC. This requires local hardware/Windows configuration.")
        open_sandbox = QPushButton("Open Windows Sandbox (if installed)")
        open_sandbox.setIcon(icon("square-stack"))
        open_sandbox.clicked.connect(self.open_sandbox)
        layout.addWidget(open_sandbox)
        layout.addStretch()
        self.tabs.addTab(page, icon("square-stack"), "Workspace")

    def open_sandbox(self):
        app = shutil.which("WindowsSandbox.exe")
        if not app and os.name == "nt":
            location = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "System32", "WindowsSandbox.exe")
            if os.path.isfile(location):
                app = location
        if not app:
            QMessageBox.information(self, "Windows Sandbox", "Windows Sandbox is not installed or is unsupported on this PC.")
            return
        try:
            subprocess.Popen([app], shell=False)
        except OSError as error:
            QMessageBox.warning(self, "Windows Sandbox", str(error))

    def refresh_status(self):
        status = self.tray.broker.status()
        mode = status["automation_profile"]
        self.automation_status.setText(f"ACTIVE: {mode.upper()} • {status['automation_seconds']} seconds remaining" if
                                       status["automation_seconds"] else "ACTIVE: MANUAL APPROVALS")
        self.access_value.setText("ENABLED" if status["enabled"] else "PAUSED")
        self.mode_label.setText("MODE: " + status["mode"].upper())
        self.toggle_button.setText("Stop access" if status["enabled"] else "Start access")
        self.tray.refresh()
        try:
            with socket.create_connection(("127.0.0.1", 8787), timeout=0.15):
                local = True
        except OSError:
            local = False
        server_error = settings_path().with_name("server-error.log")
        self.server_value.setText("LISTENING" if local else
                                  "NOT READY (see server-error.log)" if server_error.exists() else "NOT READY")
        process = self.tray.tunnel_process
        running = bool(process and process.poll() is None)
        ready = running and tunnel_ready(self.tray.tunnel_health_file)
        self.tunnel_value.setText("READY" if ready else "STARTING" if running else "NOT RUNNING")
        if process and not running:
            self.tray.last_activity = f"Tunnel exited (code {process.returncode}); check tunnel.log"
        self.activity_value.setText(self.tray.last_activity)
        if status["input_lease_seconds"]:
            self.activity_value.setText(f"UI lease: {status['input_lease_seconds']}s | " + self.tray.last_activity)
        data = self.tray.tunnel_settings()
        self.update_detail.setText("App version " + update_engine.installed_version() + " / " +
                                   ("signed update channel active" if update_engine.load_settings() else
                                    "publisher not configured; automatic updates inactive"))
        self.connection_detail.setPlainText(
            "Tunnel ID: " + data.get("tunnel_id", "not configured") + "\n"
            "Profile: " + data.get("profile", "not configured") + "\n"
            "Client: " + data.get("path", "not configured") + "\n"
            "Process: " + ("ready" if ready else "running, not ready" if running else "not running") + "\n"
            "Automatic reconnect: enabled while access is on\n"
            "Connection log: %APPDATA%\\ErzhanPC\\logs\\connection.log\n"
            "Local token: generated per application start; never displayed"
        )

    def toggle_access(self):
        self.tray.toggle_access()
        self.refresh_status()

    def set_mode(self, value):
        self.tray.change_mode(value)
        self.refresh_status()

    def stop_all(self):
        self.tray.set_access(False)
        self.refresh_status()

    def load_windows(self):
        try:
            items = ops.list_windows()
        except Exception as error:
            self.structure_text.setPlainText(str(error))
            return
        self.windows_table.setRowCount(len(items))
        for i, item in enumerate(items):
            for j, value in enumerate((item["title"], item["class_name"], item["handle"])):
                self.windows_table.setItem(i, j, QTableWidgetItem(str(value)))

    def inspect_selected(self):
        row = self.windows_table.currentRow()
        if row < 0:
            self.structure_text.setPlainText("Select a window first")
            return
        handle = int(self.windows_table.item(row, 2).text())
        try:
            result = ops.inspect_window(handle)
            lines = ["  " * x["depth"] + f"{x['type']}: {x['name']} [{x['automation_id']}]" for x in result["nodes"]]
            self.structure_text.setPlainText("\n".join(lines))
        except Exception as error:
            self.structure_text.setPlainText(str(error))

    def load_devices(self):
        def worker():
            try:
                items = ops.connected_devices(200)
            except Exception as error:
                items = [{"FriendlyName": str(error), "Class": "Error", "Status": ""}]
            self.device_signals.devices.emit(items)
        threading.Thread(target=worker, daemon=True).start()

    def render_devices(self, items):
        if not isinstance(items, list):
            items = [{"FriendlyName": str(items), "Class": "Error", "Status": ""}]
        self.devices_table.setRowCount(len(items))
        for i, item in enumerate(items):
            for j, key in enumerate(("FriendlyName", "Class", "Status")):
                self.devices_table.setItem(i, j, QTableWidgetItem(str(item.get(key) or "")))

    def load_activity(self):
        path = settings_path().with_name("activity.jsonl")
        try:
            with path.open("r", encoding="utf-8") as stream:
                entries = [json.loads(line) for line in deque(stream, maxlen=100)]
            self.activity_text.setPlainText("\n".join(
                f"{item.get('time', '')} | {item.get('result', '')} | {item.get('capability', '')} | {item.get('mode', '')}"
                for item in entries
            ))
        except (OSError, ValueError):
            self.activity_text.setPlainText("No recorded activity")
