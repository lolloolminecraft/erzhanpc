import ctypes
import json
import os
import sys
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def _native_library():
    if os.name != "nt":
        return None
    folder = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    path = folder / "erzhan_core.dll"
    if not path.is_file():
        return None
    try:
        library = ctypes.CDLL(str(path))
        library.erzhan_inventory_json.argtypes = (ctypes.c_char_p, ctypes.c_uint32)
        library.erzhan_inventory_json.restype = ctypes.c_void_p
        library.erzhan_free_json.argtypes = (ctypes.c_void_p,)
        library.erzhan_free_json.restype = None
        return library
    except (OSError, AttributeError):
        return None


def native_inventory(directory, limit):
    library = _native_library()
    if library is None:
        return None
    try:
        result = library.erzhan_inventory_json(str(directory).encode("utf-8"), limit)
        if not result:
            return None
        try:
            payload = ctypes.string_at(result)
        finally:
            library.erzhan_free_json(result)
        inventory = json.loads(payload.decode("utf-8"))
        if inventory.get("directory") != str(directory) or not isinstance(inventory.get("files_by_size"), list):
            return None
        return inventory
    except (OSError, ValueError, TypeError, UnicodeError):
        return None
