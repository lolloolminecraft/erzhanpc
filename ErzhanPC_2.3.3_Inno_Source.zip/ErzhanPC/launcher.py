import update_engine


update_engine.activate_verified_patch()

from main import main


if __name__ == "__main__":
    raise SystemExit(main())
