import io
import os
import shutil
import subprocess
import time
from pathlib import Path

import psutil


def powershell(command, timeout=60):
    executable = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
    if not executable:
        raise RuntimeError("PowerShell was not found")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run(
        [executable, "-NoProfile", "-NonInteractive", "-Command", command],
        capture_output=True,
        text=True,
        errors="replace",
        timeout=max(1, min(int(timeout), 90)),
        creationflags=flags,
    )
    return {
        "exit_code": result.returncode,
        "stdout": result.stdout[-32000:],
        "stderr": result.stderr[-12000:],
    }


def run_program(path, args=None):
    executable = os.path.expandvars(os.path.expanduser(path))
    flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0) if Path(executable).name.lower() in {"powershell.exe", "pwsh.exe", "cmd.exe"} else 0
    process = subprocess.Popen([executable, *(args or [])], shell=False, creationflags=flags)
    return {"pid": process.pid, "path": executable}


def list_windows():
    from pywinauto import Desktop

    windows = []
    for window in Desktop(backend="uia").windows():
        try:
            info = window.element_info
            rect = window.rectangle()
            if info.name:
                windows.append({
                    "handle": info.handle,
                    "title": info.name[:200],
                    "class_name": info.class_name,
                    "bounds": [rect.left, rect.top, rect.right, rect.bottom],
                })
        except Exception:
            continue
    return windows[:120]


def inspect_window(handle, max_depth=5, max_nodes=180):
    from pywinauto import Desktop

    window = Desktop(backend="uia").window(handle=int(handle))
    root = window.wrapper_object()
    output = []
    remaining = [max(1, min(int(max_nodes), 400))]

    def walk(node, depth):
        if remaining[0] <= 0:
            return
        remaining[0] -= 1
        info = node.element_info
        try:
            rect = node.rectangle()
            bounds = [rect.left, rect.top, rect.right, rect.bottom]
        except Exception:
            bounds = None
        output.append({
            "depth": depth,
            "name": (info.name or "")[:180],
            "type": info.control_type,
            "automation_id": info.automation_id,
            "bounds": bounds,
            "enabled": node.is_enabled(),
        })
        if depth >= max(0, min(int(max_depth), 8)):
            return
        try:
            children = node.children()
        except Exception:
            children = []
        for child in children:
            walk(child, depth + 1)
            if remaining[0] <= 0:
                break

    walk(root, 0)
    return {"handle": int(handle), "nodes": output, "truncated": remaining[0] == 0}


def click_control(handle, automation_id=None, name=None, control_type=None, index=0):
    target, count = _find_control(handle, automation_id, name, control_type, index)
    try:
        target.invoke()
    except Exception:
        target.click_input()
    return {"matched": count, "selected": int(index), "name": target.element_info.name}


def _find_control(handle, automation_id=None, name=None, control_type=None, index=0):
    from pywinauto import Desktop

    if automation_id is None and name is None:
        raise ValueError("Specify automation_id or name")
    window = Desktop(backend="uia").window(handle=int(handle))
    matches = []
    for node in window.descendants():
        info = node.element_info
        if automation_id is not None and info.automation_id != automation_id:
            continue
        if name is not None and info.name != name:
            continue
        if control_type is not None and info.control_type != control_type:
            continue
        matches.append(node)
        if len(matches) > 500:
            break
    if not matches or int(index) < 0 or int(index) >= len(matches):
        raise LookupError("Requested Windows control was not found")
    target = matches[int(index)]
    return target, len(matches)


def control_read_text(handle, automation_id=None, name=None, control_type=None, index=0):
    target, count = _find_control(handle, automation_id, name, control_type, index)
    content = None
    try:
        content = target.iface_text.DocumentRange.GetText(16000)
    except Exception:
        try:
            content = target.iface_value.CurrentValue
        except Exception:
            content = target.window_text()
    return {"matched": count, "name": target.element_info.name, "text": str(content or "")[:16000]}


def control_set_text(handle, text, automation_id=None, name=None, index=0):
    if len(text) > 30000:
        raise ValueError("Text exceeds the single-control limit")
    target, count = _find_control(handle, automation_id, name, "Edit", index)
    target.set_edit_text(text)
    return {"matched": count, "name": target.element_info.name, "characters": len(text)}


def take_screenshot(monitor=1):
    import mss
    from PIL import Image

    with mss.mss() as session:
        monitors = session.monitors
        index = min(max(int(monitor), 0), len(monitors) - 1)
        shot = session.grab(monitors[index])
        picture = Image.frombytes("RGB", shot.size, shot.rgb)
        stream = io.BytesIO()
        picture.save(stream, format="JPEG", quality=75, optimize=True)
        return stream.getvalue()


def capture_window(handle):
    import mss
    from PIL import Image
    from pywinauto import Desktop

    target = Desktop(backend="uia").window(handle=int(handle))
    rectangle = target.rectangle()
    width = rectangle.right - rectangle.left
    height = rectangle.bottom - rectangle.top
    if width <= 0 or height <= 0 or width * height > 20000000:
        raise ValueError("Window bounds are invalid or too large")
    with mss.mss() as session:
        shot = session.grab({"left": rectangle.left, "top": rectangle.top,
                             "width": width, "height": height})
        image = Image.frombytes("RGB", shot.size, shot.rgb)
        image.thumbnail((1800, 1200), Image.Resampling.LANCZOS)
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=75, optimize=True)
        return buffer.getvalue()


def mouse_click(x, y, button="left", clicks=1):
    import pyautogui

    pyautogui.FAILSAFE = True
    pyautogui.click(x=int(x), y=int(y), button=button, clicks=min(max(int(clicks), 1), 3))
    return "ok"


def mouse_move(x, y):
    import pyautogui

    pyautogui.FAILSAFE = True
    pyautogui.moveTo(int(x), int(y), duration=0)
    return "ok"


def mouse_scroll(amount):
    import pyautogui

    pyautogui.FAILSAFE = True
    pyautogui.scroll(max(-20, min(int(amount), 20)))
    return "ok"


def type_text(text, interval=0.01):
    import pyautogui
    import pyperclip
    import time

    pyautogui.FAILSAFE = True
    old_clipboard = None
    try:
        old_clipboard = pyperclip.paste()
    except Exception:
        pass
    pyperclip.copy(text)
    pyautogui.hotkey("ctrl", "v")
    time.sleep(0.1)
    if old_clipboard is not None:
        pyperclip.copy(old_clipboard)
    return "ok"


def press_keys(keys):
    import pyautogui

    pyautogui.FAILSAFE = True
    key_list = [key.strip().lower() for key in keys.split("+") if key.strip()]
    if not key_list or len(key_list) > 5:
        raise ValueError("Invalid keyboard shortcut")
    pyautogui.hotkey(*key_list)
    return "ok"


def focus_window(handle):
    from pywinauto import Desktop

    window = Desktop(backend="uia").window(handle=int(handle))
    window.restore()
    window.set_focus()
    return {"handle": int(handle), "focused": True}


def perform_actions(actions):
    if not isinstance(actions, list) or not 1 <= len(actions) <= 25:
        raise ValueError("Provide 1 to 25 desktop actions")
    result = []
    for i, action in enumerate(actions):
        if not isinstance(action, dict):
            raise ValueError("Each action must be an object")
        kind = action.get("kind")
        if kind == "click":
            item = mouse_click(action["x"], action["y"], action.get("button", "left"), action.get("clicks", 1))
        elif kind == "move":
            item = mouse_move(action["x"], action["y"])
        elif kind == "scroll":
            item = mouse_scroll(action["amount"])
        elif kind == "type":
            item = type_text(action["text"])
        elif kind == "shortcut":
            item = press_keys(action["keys"])
        elif kind == "focus":
            item = focus_window(action["handle"])
        elif kind == "control_click":
            item = click_control(action["handle"], action.get("automation_id"), action.get("name"), action.get("control_type"), action.get("index", 0))
        elif kind == "control_set_text":
            item = control_set_text(action["handle"], action["text"], action.get("automation_id"), action.get("name"), action.get("index", 0))
        elif kind == "wait":
            duration = max(0, min(float(action.get("seconds", 0.25)), 2))
            time.sleep(duration)
            item = {"seconds": duration}
        else:
            raise ValueError(f"Unsupported action at index {i}")
        result.append({"index": i, "kind": kind, "result": item})
    return {"completed": len(result), "results": result}


def connected_devices(limit=100):
    script = "Get-PnpDevice -PresentOnly | Select-Object FriendlyName,Class,Status,InstanceId | ConvertTo-Json -Depth 2 -Compress"
    result = powershell(script, timeout=30)
    if result["exit_code"] != 0:
        return result
    import json

    payload = json.loads(result["stdout"] or "[]")
    devices = payload if isinstance(payload, list) else [payload]
    return devices[:max(1, min(int(limit), 300))]


def list_drives():
    return [
        {"drive": part.device, "mountpoint": part.mountpoint, "fstype": part.fstype}
        for part in psutil.disk_partitions(all=False)
    ]


def list_files(directory, limit=100):
    folder = Path(os.path.expandvars(directory)).expanduser()
    output = []
    for child in folder.iterdir():
        try:
            stat = child.stat()
            output.append({"name": child.name, "path": str(child), "is_dir": child.is_dir(), "bytes": stat.st_size})
        except OSError:
            continue
        if len(output) >= max(1, min(int(limit), 500)):
            break
    return {"directory": str(folder.resolve()), "items": output}


def read_file(path, max_bytes=120000):
    target = Path(os.path.expandvars(path)).expanduser()
    count = max(1, min(int(max_bytes), 500000))
    with target.open("rb") as stream:
        data = stream.read(count + 1)
    if b"\x00" in data:
        raise ValueError("Binary file: use an appropriate viewer")
    return {"path": str(target), "text": data[:count].decode("utf-8-sig", errors="replace"), "truncated": len(data) > count}


def write_file(path, text, overwrite=False):
    target = Path(os.path.expandvars(path)).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    mode = "w" if overwrite else "x"
    with target.open(mode, encoding="utf-8", newline="") as stream:
        stream.write(text)
    return {"path": str(target), "bytes": len(text.encode("utf-8"))}


def rename_file(path, new_name):
    if not new_name or new_name in {".", ".."} or any(x in new_name for x in '<>:"/\\|?*'):
        raise ValueError("Invalid file name")
    source = Path(os.path.expandvars(path)).expanduser()
    if not source.exists():
        raise FileNotFoundError(str(source))
    target = source.with_name(new_name)
    if target.exists() and source != target:
        raise FileExistsError(str(target))
    source.rename(target)
    return {"old_path": str(source), "new_path": str(target)}


def trash_file(path):
    from send2trash import send2trash

    target = Path(os.path.expandvars(path)).expanduser()
    if not target.exists():
        raise FileNotFoundError(str(target))
    send2trash(str(target))
    return {"moved_to_recycle_bin": str(target)}


def processes(limit=100):
    output = []
    for process in psutil.process_iter(attrs=["pid", "name", "exe"]):
        try:
            output.append(process.info)
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            continue
        if len(output) >= max(1, min(int(limit), 400)):
            break
    return output
