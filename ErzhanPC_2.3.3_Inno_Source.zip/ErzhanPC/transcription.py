import json
import os
import secrets
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import media_ops


API_URL = "https://api.openai.com/v1/audio/transcriptions"
CHUNK_SECONDS = 360
MAX_TRANSCRIPTION_SECONDS = 3600


def extract_audio(path, output, start, length):
    import imageio_ffmpeg

    result = subprocess.run(
        [imageio_ffmpeg.get_ffmpeg_exe(), "-nostdin", "-hide_banner", "-loglevel", "error",
         "-ss", f"{start:.3f}", "-i", str(path), "-vn", "-t", f"{length:.3f}",
         "-ac", "1", "-ar", "16000", "-b:a", "32k", "-y", str(output)],
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=130,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if result.returncode or not output.is_file() or output.stat().st_size < 100:
        raise RuntimeError("Audio extraction failed; the video may not contain a sound track")
    if output.stat().st_size > 25000000:
        raise ValueError("Audio chunk exceeds the transcription file limit")


def transcribe_audio(audio_bytes, api_key, request_opener=None):
    boundary = "erzhan-" + secrets.token_hex(12)
    prefix = (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\ngpt-transcribe\r\n"
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.mp3\"\r\n"
        "Content-Type: audio/mpeg\r\n\r\n"
    ).encode("ascii")
    body = prefix + audio_bytes + f"\r\n--{boundary}--\r\n".encode("ascii")
    request = urllib.request.Request(
        API_URL, data=body, method="POST",
        headers={"Authorization": "Bearer " + api_key,
                 "Content-Type": "multipart/form-data; boundary=" + boundary},
    )
    opener = request_opener or urllib.request.urlopen
    try:
        with opener(request, timeout=150) as response:
            if response.geturl() != API_URL:
                raise ValueError("Unexpected transcription endpoint redirect")
            payload = response.read(250000 + 1)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f"Transcription service returned HTTP {error.code}") from None
    if len(payload) > 250000:
        raise ValueError("Transcription reply too large")
    data = json.loads(payload)
    if not isinstance(data, dict) or not isinstance(data.get("text"), str):
        raise ValueError("Unexpected transcription reply")
    return data["text"]


class TranscriptionJobs:
    def __init__(self):
        self.jobs = {}
        self.lock = threading.Lock()

    def start(self, path, api_key, start_second=0, duration_seconds=600):
        target = media_ops.media_path(path, media_ops.VIDEO_EXTENSIONS)
        duration = media_ops.video_info(str(target))["duration_seconds"]
        start = float(start_second)
        length = float(duration_seconds)
        if start < 0 or start >= duration:
            raise ValueError("Start time is outside the video")
        if not 1 <= length <= MAX_TRANSCRIPTION_SECONDS:
            raise ValueError("Length must be between 1 second and 1 hour")
        length = min(length, duration - start)
        task = secrets.token_urlsafe(12)
        with self.lock:
            if len(self.jobs) >= 30:
                oldest = next((identifier for identifier, info in self.jobs.items() if info["status"] != "running"), None)
                if not oldest:
                    raise RuntimeError("Too many concurrent transcription jobs")
                self.jobs.pop(oldest, None)
            self.jobs[task] = {"status": "running", "progress": 0, "text": "", "started": time.time()}

        def work():
            texts = []
            position = start
            try:
                with tempfile.TemporaryDirectory(prefix="erzhan-transcribe-") as folder:
                    while position < start + length - 0.01:
                        seconds = min(CHUNK_SECONDS, start + length - position)
                        audio = Path(folder) / "clip.mp3"
                        extract_audio(target, audio, position, seconds)
                        chunk = transcribe_audio(audio.read_bytes(), api_key)
                        texts.append(chunk)
                        position += seconds
                        with self.lock:
                            self.jobs[task].update({"progress": round(100 * (position - start) / length),
                                                    "text": "\n".join(texts)[:80000]})
                with self.lock:
                    self.jobs[task]["status"] = "finished"
            except Exception as error:
                with self.lock:
                    self.jobs[task].update({"status": "error", "error": str(error)[:600]})

        threading.Thread(target=work, daemon=True).start()
        return {"job_id": task, "status": "running", "duration_seconds": length,
                "note": "Audio will be sent to OpenAI's transcription API using the locally saved key"}

    def status(self, job_id):
        with self.lock:
            if job_id not in self.jobs:
                raise KeyError("Transcription job not found")
            info = self.jobs[job_id].copy()
        return {"job_id": job_id, **info}
