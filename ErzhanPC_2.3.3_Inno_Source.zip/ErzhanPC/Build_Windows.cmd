@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    where python >nul 2>&1
    if errorlevel 1 (
        py -3.12 -m venv .venv
    ) else (
        python -m venv .venv
    )
)
if errorlevel 1 exit /b 1
set "ERZHAN_NATIVE_BINARY="
where rustc >nul 2>&1
if not errorlevel 1 (
    rustc --edition=2021 --crate-type=cdylib -C opt-level=3 -C panic=abort --crate-name erzhan_core native\erzhan_core.rs -o native\erzhan_core.dll
    if errorlevel 1 exit /b 1
    set "ERZHAN_NATIVE_BINARY=--add-binary native\erzhan_core.dll;."
)
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --name ErzhanPC --icon icons\ErzhanPC.ico --add-data "icons;icons" %ERZHAN_NATIVE_BINARY% --collect-submodules mcp.server --collect-data mcp --collect-all pywinauto --collect-all pyautogui --collect-all imageio_ffmpeg --collect-all openpyxl --collect-all pptx --collect-all docx --collect-all pypdf --collect-all cryptography --hidden-import=PySide6.QtSvg --hidden-import=pywinauto.controls.uiawrapper --hidden-import=pywinauto.application --hidden-import=uvicorn.protocols.http.h11_impl --hidden-import=uvicorn.lifespan.on --hidden-import=uvicorn.loops.asyncio --hidden-import=h11 --hidden-import=starlette launcher.py
if errorlevel 1 exit /b 1
echo Build complete: dist\ErzhanPC\ErzhanPC.exe
exit /b 0
