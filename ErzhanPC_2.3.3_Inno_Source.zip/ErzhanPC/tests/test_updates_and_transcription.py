import base64
import hashlib
import json
import os
import sys
import tempfile
import time
import unittest
import importlib.util
import io
import zipfile
from pathlib import Path
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

import transcription
import update_engine

_signer_spec = importlib.util.spec_from_file_location("release_signer", Path(__file__).resolve().parents[2] / "InstallerWin" / "sign_release.py")
_release_signer = importlib.util.module_from_spec(_signer_spec)
_signer_spec.loader.exec_module(_release_signer)


class MockResponse:
    def __init__(self, url, content):
        self.url = url
        self.content = content
        self.position = 0
        self.headers = {"Content-Length": str(len(content))}

    def geturl(self):
        return self.url

    def read(self, limit=-1):
        if limit < 0:
            limit = len(self.content) - self.position
        result = self.content[self.position:self.position + limit]
        self.position += len(result)
        return result

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False


class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.private = Ed25519PrivateKey.generate()
        public = self.private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
        self.public_hex = public.hex()
        self.next_version = "2.3.4"
        self.url = "https://releases.example.com/ErzhanPC_Setup_2.3.4.exe"
        self.payload = b"MZ verified dummy Windows package"
        self.manifest = {"version": self.next_version, "url": self.url, "sha256": hashlib.sha256(self.payload).hexdigest()}
        self.manifest["signature"] = base64.b64encode(self.private.sign(update_engine.canonical_payload(
            self.manifest["version"], self.manifest["url"], self.manifest["sha256"]))).decode()

    def tearDown(self):
        self.temp.cleanup()

    def test_signed_manifest_accepted_and_downgrade_ignored(self):
        self.assertEqual(update_engine.verify_manifest(self.manifest, self.public_hex)["version"], self.next_version)
        self.assertIsNone(update_engine.verify_manifest(self.manifest, self.public_hex, "2.4.0"))

    def test_tampered_and_invalid_transport_rejected(self):
        changed = {**self.manifest, "url": "https://attacker.example/file.exe"}
        with self.assertRaisesRegex(ValueError, "signature"):
            update_engine.verify_manifest(changed, self.public_hex)
        with self.assertRaisesRegex(ValueError, "HTTPS"):
            update_engine.validate_settings("http://localhost/update.json", self.public_hex)
        with self.assertRaises(ValueError):
            update_engine.verify_manifest({**self.manifest, "url": "http://malware.test/setup.exe"}, self.public_hex)

    def test_fetch_and_file_checksum(self):
        feed = "https://releases.example.com/update.json"
        settings = {"feed_url": feed, "public_key": self.public_hex}
        manifest_bytes = json.dumps(self.manifest).encode()
        fetched = update_engine.check_update(settings, open_url=lambda req, timeout: MockResponse(feed, manifest_bytes))
        result = update_engine.download_verified_installer(fetched, self.temp.name,
            open_url=lambda req, timeout: MockResponse(self.url, self.payload))
        self.assertEqual(result.read_bytes(), self.payload)
        with self.assertRaisesRegex(ValueError, "mismatch"):
            update_engine.download_verified_installer(fetched, self.temp.name,
                open_url=lambda req, timeout: MockResponse(self.url, b"untrusted bytes"))

    def test_installer_download_reports_true_byte_progress(self):
        progress = []
        result = update_engine.download_verified_installer(self.manifest, self.temp.name,
            open_url=lambda req, timeout: MockResponse(self.url, self.payload),
            progress_callback=lambda received, expected: progress.append((received, expected)))
        self.assertEqual(result.read_bytes(), self.payload)
        self.assertEqual(progress[-1], (len(self.payload), len(self.payload)))

    def test_local_settings_do_not_contain_a_private_signing_key(self):
        with patch.dict(os.environ, {"APPDATA": self.temp.name}):
            update_engine.save_settings("https://releases.example.com/update.json", self.public_hex)
            loaded = update_engine.load_settings()
            self.assertEqual(loaded["public_key"], self.public_hex)
            self.assertNotIn("private", update_engine.config_path().read_text())

    def test_publisher_signer_produces_a_verifiable_release(self):
        root = Path(self.temp.name)
        pem = root / "publisher.pem"
        executable = root / "installer.exe"
        executable.write_bytes(self.payload)
        public_key = _release_signer.create_key(pem, "publisher-passphrase")
        manifest = _release_signer.sign_release(pem, "publisher-passphrase", executable,
                                                self.next_version, self.url, root / "update.json")
        self.assertEqual(update_engine.verify_manifest(manifest, public_key)["version"], self.next_version)
        self.assertNotIn(b"BEGIN PRIVATE KEY", pem.read_bytes())

    def _patch_bundle(self, entries=None):
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in (entries or {"dashboard.py": b"VALUE = 123\n"}).items():
                archive.writestr(name, data)
        content = output.getvalue()
        url = "https://releases.example.com/ErzhanPC_Patch_2.3.4.zip"
        manifest = {"kind": "patch", "base_version": update_engine.APP_VERSION, "version": self.next_version, "url": url,
                    "sha256": hashlib.sha256(content).hexdigest()}
        manifest["signature"] = base64.b64encode(self.private.sign(update_engine.canonical_patch_payload(
            manifest["version"], manifest["base_version"], url, manifest["sha256"]))).decode()
        return manifest, content

    def test_verified_incremental_patch_installation_and_activation(self):
        patch_manifest, content = self._patch_bundle()
        with patch.dict(os.environ, {"APPDATA": self.temp.name}):
            settings = update_engine.save_settings("https://releases.example.com/feed.json", self.public_hex)
            verified = update_engine.verify_manifest(patch_manifest, self.public_hex)
            self.assertEqual(verified["kind"], "patch")
            path = update_engine.download_verified_patch(verified, settings,
                open_url=lambda req, timeout: MockResponse(patch_manifest["url"], content))
            self.assertEqual(path.read_bytes(), content)
            self.assertTrue(update_engine.activate_verified_patch(settings))
            self.assertEqual(update_engine.installed_version(), self.next_version)
            try:
                self.assertIsNotNone(sys.meta_path[0].find_spec("dashboard"))
            finally:
                sys.meta_path.pop(0)
                update_engine._active_patch = None
                update_engine._active_version = update_engine.APP_VERSION

    def test_patch_signature_invalid_or_archive_unsafe(self):
        patch_manifest, content = self._patch_bundle({"../outside.py": b"harm"})
        with patch.dict(os.environ, {"APPDATA": self.temp.name}):
            settings = update_engine.save_settings("https://releases.example.com/feed.json", self.public_hex)
            with self.assertRaisesRegex(ValueError, "entry"):
                update_engine.download_verified_patch(patch_manifest, settings,
                    open_url=lambda req, timeout: MockResponse(patch_manifest["url"], content))
            with self.assertRaisesRegex(ValueError, "signature"):
                update_engine.verify_manifest({**patch_manifest, "url": "https://attacker.example.com/payload.zip"}, self.public_hex)

    def test_idle_channel_is_signed_and_reports_no_update(self):
        signature = base64.b64encode(self.private.sign(update_engine.canonical_idle_payload(update_engine.APP_VERSION))).decode()
        idle = {"kind": "idle", "version": update_engine.APP_VERSION, "signature": signature}
        self.assertIsNone(update_engine.verify_manifest(idle, self.public_hex))
        with self.assertRaisesRegex(ValueError, "signature"):
            update_engine.verify_manifest({**idle, "signature": signature[:-2] + "AA"}, self.public_hex)


class SpeechTests(unittest.TestCase):
    def test_transcription_uses_current_model_without_leaking_secret(self):
        captured = {}

        def open_url(request, timeout):
            captured["headers"] = dict(request.header_items())
            captured["body"] = request.data
            return MockResponse(transcription.API_URL, b'{"text":"Hello Erzhan"}')

        result = transcription.transcribe_audio(b"fake-mp3", "private-key", open_url)
        self.assertEqual(result, "Hello Erzhan")
        self.assertIn(b"gpt-transcribe", captured["body"])
        self.assertIn(b"fake-mp3", captured["body"])

    def test_jobs_report_progress_after_mocked_cloud_call(self):
        with tempfile.TemporaryDirectory() as directory:
            video = Path(directory) / "sample.mp4"
            video.write_bytes(b"video")
            manager = transcription.TranscriptionJobs()

            def extract(path, output, start, length):
                output.write_bytes(b"fake-audio")

            with patch("transcription.media_ops.video_info", return_value={"duration_seconds": 120}), \
                 patch("transcription.extract_audio", side_effect=extract), \
                 patch("transcription.transcribe_audio", return_value="Test transcript"):
                task = manager.start(str(video), "secret", duration_seconds=30)
                for _ in range(100):
                    info = manager.status(task["job_id"])
                    if info["status"] != "running":
                        break
                    time.sleep(0.01)
            self.assertEqual(info["status"], "finished")
            self.assertEqual(info["progress"], 100)
            self.assertEqual(info["text"], "Test transcript")


if __name__ == "__main__":
    unittest.main()
