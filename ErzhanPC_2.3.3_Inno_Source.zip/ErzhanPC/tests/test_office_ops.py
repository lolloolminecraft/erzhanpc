import hashlib
import tempfile
import unittest
from pathlib import Path

from docx import Document
from openpyxl import Workbook, load_workbook
from pypdf import PdfWriter
from pptx import Presentation

import office_ops


class OfficeOpsTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.root = Path(self.folder.name)

    def tearDown(self):
        self.folder.cleanup()

    def test_word_preview_and_run_preserving_replacement(self):
        path = self.root / "sample.docx"
        document = Document()
        paragraph = document.add_paragraph()
        run = paragraph.add_run("Hello world")
        run.bold = True
        document.save(path)

        preview = office_ops.office_preview(str(path))
        self.assertIn("Hello world", preview["text"])
        original_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        updated = office_ops.word_replace_text(str(path), "world", "Erzhan", expected_sha256=original_hash)
        self.assertEqual(updated["replacements"], 1)
        self.assertTrue(Path(updated["backup"]).exists())
        result = Document(str(path))
        self.assertEqual(result.paragraphs[0].text, "Hello Erzhan")
        self.assertTrue(result.paragraphs[0].runs[0].bold)

    def test_word_split_runs_rejected(self):
        path = self.root / "split.docx"
        document = Document()
        p = document.add_paragraph()
        p.add_run("Hel")
        p.add_run("lo")
        document.save(path)
        with self.assertRaises(ValueError):
            office_ops.word_replace_text(str(path), "Hello", "Hi")

    def test_excel_preview_and_cell_update(self):
        path = self.root / "table.xlsx"
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.title = "Sales"
        worksheet["A1"] = "Item"
        worksheet["B1"] = 15
        worksheet["A2"] = "Paper"
        workbook.save(path)
        preview = office_ops.office_preview(str(path), "Sales")
        self.assertEqual(preview["rows"][0][:2], ["Item", 15])
        updated = office_ops.spreadsheet_set_cell(str(path), "Sales", "B1", 25)
        self.assertTrue(updated["changed"])
        self.assertTrue(Path(updated["backup"]).exists())
        self.assertEqual(load_workbook(path).active["B1"].value, 25)
        with self.assertRaises(ValueError):
            office_ops.spreadsheet_set_cell(str(path), "Sales", "B1", 26, expected_sha256="0" * 64)

    def test_powerpoint_and_pdf_preview(self):
        slides = Presentation()
        page = slides.slides.add_slide(slides.slide_layouts[0])
        page.shapes.title.text = "Hello slide"
        pptx = self.root / "slides.pptx"
        slides.save(pptx)
        result = office_ops.office_preview(str(pptx))
        self.assertEqual(result["total_slides"], 1)
        self.assertIn("Hello slide", result["slides"][0]["text"])

        writer = PdfWriter()
        writer.add_blank_page(width=250, height=200)
        pdf_path = self.root / "blank.pdf"
        with pdf_path.open("wb") as stream:
            writer.write(stream)
        preview = office_ops.office_preview(str(pdf_path))
        self.assertEqual(preview["total_pages"], 1)
        self.assertIn("OCR", preview["note"])


if __name__ == "__main__":
    unittest.main()
