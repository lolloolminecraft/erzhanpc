import hashlib
import io
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import document_ops
import media_ops


class MediaTests(unittest.TestCase):
    def test_image_returns_scaled_jpeg(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "photo.png"
            Image.new("RGB", (2000, 1000), "red").save(path)
            preview = media_ops.image_preview(str(path), 700)
            with Image.open(io.BytesIO(preview)) as rendered:
                self.assertEqual(rendered.size, (700, 350))
                self.assertEqual(rendered.format, "JPEG")

    def test_video_frame_is_decoded_with_safe_arguments(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "clip.mp4"
            path.write_bytes(b"test")
            frame = io.BytesIO()
            Image.new("RGB", (64, 40), "blue").save(frame, format="JPEG")

            class FFmpeg:
                @staticmethod
                def get_ffmpeg_exe():
                    return "ffmpeg-test"

            result = type("Result", (), {"returncode": 0, "stdout": frame.getvalue(), "stderr": b""})()
            with patch.dict(sys.modules, {"imageio_ffmpeg": FFmpeg}), patch("media_ops.subprocess.run", return_value=result) as command:
                output = media_ops.video_frame(str(path), 2.5)
            self.assertEqual(output, frame.getvalue())
            arguments = command.call_args.args[0]
            self.assertEqual(arguments[0], "ffmpeg-test")
            self.assertIn(str(path.resolve()), arguments)
            self.assertIn("-nostdin", arguments)
            self.assertIn("2.500", arguments)
            with self.assertRaises(ValueError):
                media_ops.video_frame(str(path), -1)

    def test_storyboard_contains_sampled_images(self):
        with patch("media_ops.video_info", return_value={"duration_seconds": 60}), patch("media_ops.video_frame") as frame:
            image = io.BytesIO()
            Image.new("RGB", (200, 100), "green").save(image, format="JPEG")
            frame.return_value = image.getvalue()
            output = media_ops.video_contact_sheet("clip.mp4", 6)
        self.assertEqual(frame.call_count, 6)
        with Image.open(io.BytesIO(output)) as sheet:
            self.assertEqual(sheet.size, (1440, 580))


class DocumentTests(unittest.TestCase):
    def test_exact_text_edit_creates_backup(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "notes.txt"
            path.write_text("First line\nHello\n", encoding="utf-8")
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            result = document_ops.text_replace(str(path), "Hello", "Привет", expected_sha256=digest)
            self.assertIn("Привет", path.read_text(encoding="utf-8"))
            self.assertEqual(Path(result["backup"]).read_text(encoding="utf-8"), "First line\nHello\n")
            self.assertEqual(result["replacements"], 1)

    def test_text_edit_rejects_ambiguous_matches_and_modified_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "notes.txt"
            path.write_text("A A A", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "3 matches"):
                document_ops.text_replace(str(path), "A", "B")
            with self.assertRaisesRegex(ValueError, "File changed"):
                document_ops.text_replace(str(path), "A", "B", expected_sha256="0" * 64)
            self.assertEqual(path.read_text(encoding="utf-8"), "A A A")

    def test_move_does_not_overwrite_and_preserves_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            parent = Path(directory)
            destination = parent / "sorted"
            destination.mkdir()
            source = parent / "report.pdf"
            source.write_bytes(b"original")
            existing = destination / "report.pdf"
            existing.write_bytes(b"keep")
            with self.assertRaises(FileExistsError):
                document_ops.move_file(str(source), str(existing))
            self.assertEqual(existing.read_bytes(), b"keep")
            moved = destination / "report-copy.pdf"
            result = document_ops.move_file(str(source), str(moved))
            self.assertEqual(result["new_path"], str(moved))
            self.assertEqual(moved.read_bytes(), b"original")
            self.assertFalse(source.exists())

    def test_folder_inventory_and_file_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            nested = root / "nested"
            nested.mkdir()
            (root / "small.txt").write_bytes(b"1")
            large = nested / "large.txt"
            large.write_bytes(b"abc" * 100)
            result = document_ops.folder_inventory(str(root))
            self.assertEqual(result["scanned_files"], 2)
            self.assertEqual(Path(result["files_by_size"][0]["path"]).resolve(), large.resolve())
            self.assertFalse(result["truncated"])
            digest = document_ops.file_hash(str(large))
            self.assertEqual(digest["sha256"], hashlib.sha256(large.read_bytes()).hexdigest())

    def test_documents_refuse_executable_files(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "program.exe"
            path.write_bytes(b"binary")
            with self.assertRaisesRegex(ValueError, "Unsupported document"):
                document_ops.open_document(str(path))

    def test_organization_uses_preview_hash_and_does_not_delete(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "photo.jpg").write_bytes(b"photo")
            (root / "report.docx").write_bytes(b"office")
            (root / "download.crdownload").write_bytes(b"unfinished")
            preview = document_ops.organization_plan(str(root))
            self.assertEqual(preview["count"], 2)
            (root / "report.docx").write_bytes(b"modified")
            with self.assertRaisesRegex(ValueError, "changed"):
                document_ops.organization_apply(str(root), preview["plan_sha256"])
            new_plan = document_ops.organization_plan(str(root))
            result = document_ops.organization_apply(str(root), new_plan["plan_sha256"])
            self.assertEqual(result["moved"], 2)
            self.assertEqual((root / "Images" / "photo.jpg").read_bytes(), b"photo")
            self.assertEqual((root / "Documents" / "report.docx").read_bytes(), b"modified")
            self.assertTrue((root / "download.crdownload").exists())


if __name__ == "__main__":
    unittest.main()
