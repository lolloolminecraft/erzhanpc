import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import document_ops
import fast_inventory


class NativeInventoryTests(unittest.TestCase):
    def test_fallback_scans_folder_without_native_library(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "large.bin").write_bytes(b"a" * 32)
            (root / "small.txt").write_bytes(b"a" * 4)
            with patch("fast_inventory._native_library", return_value=None):
                result = document_ops.folder_inventory(directory, 1)
            self.assertEqual(result["scanned_files"], 1)
            self.assertTrue(result["truncated"])
            self.assertEqual(len(result["files_by_size"]), 1)

    def test_native_result_is_returned_when_valid(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            native = {"directory": str(root), "scanned_files": 0, "truncated": False,
                      "total_bytes_scanned": 0, "files_by_size": []}

            class NativeLibrary:
                def erzhan_inventory_json(self, path, limit):
                    self.assert_path = path
                    self.assert_limit = limit
                    self.bytes = json.dumps(native).encode("utf-8")
                    return 123

                def erzhan_free_json(self, value):
                    self.freed = value

            library = NativeLibrary()
            with patch("fast_inventory._native_library", return_value=library), \
                 patch("fast_inventory.ctypes.string_at", return_value=json.dumps(native).encode("utf-8")):
                self.assertEqual(document_ops.folder_inventory(str(root)), native)
            self.assertEqual(library.freed, 123)

    def test_invalid_native_payload_falls_back(self):
        with tempfile.TemporaryDirectory() as directory:
            (Path(directory) / "data.bin").write_bytes(b"data")
            with patch("fast_inventory._native_library", return_value=None):
                self.assertIsNone(fast_inventory.native_inventory(directory, 200))
            with patch("fast_inventory.native_inventory", return_value=None):
                self.assertEqual(document_ops.folder_inventory(directory)["scanned_files"], 1)


if __name__ == "__main__":
    unittest.main()
