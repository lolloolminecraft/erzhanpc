import os
import json
import tempfile
import threading
import time
import unittest
import urllib.request
from pathlib import Path
from unittest.mock import patch

from approval import ApprovalBroker
from secure_transport import run_secured
import windows_ops
from bridge import create_bridge


class BrokerTests(unittest.TestCase):
    def test_permission_persistence_and_revocation(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"APPDATA": directory}):
                broker = ApprovalBroker(lambda capability, detail: "once")
                broker.set_mode("full")
                broker.set_enabled(True)
                broker.request("screen", "test")
                self.assertEqual(broker.status()["mode"], "full")
                reloaded = ApprovalBroker(lambda capability, detail: "deny")
                self.assertFalse(reloaded.enabled)
                with self.assertRaises(PermissionError):
                    reloaded.request("screen", "blocked until local start")
                reloaded.set_enabled(True)
                reloaded.request("screen", "allowed")
                reloaded.revoke()
                reloaded.set_enabled(False)
                with self.assertRaises(PermissionError):
                    reloaded.request("screen", "denied")

    def test_pause_denies_even_always(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"APPDATA": directory}):
                broker = ApprovalBroker(lambda capability, detail: "once")
                broker.set_mode("full")
                broker.set_enabled(True)
                broker.request("shell", "test")
                broker.set_enabled(False)
                with self.assertRaises(PermissionError):
                    broker.request("shell", "blocked")


class FileTests(unittest.TestCase):
    def test_file_write_requires_explicit_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "demo.txt")
            windows_ops.write_file(path, "Hello")
            with self.assertRaises(FileExistsError):
                windows_ops.write_file(path, "Another")
            windows_ops.write_file(path, "Привет", overwrite=True)
            self.assertEqual(windows_ops.read_file(path)["text"], "Привет")

    def test_bridge_registers_tools(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"APPDATA": directory}):
                broker = ApprovalBroker(lambda capability, detail: "deny")
                server = create_bridge(broker)
                self.assertEqual(server.name, "Erzhan PC")


class McpProtocolTests(unittest.TestCase):
    def test_http_initialize(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"APPDATA": directory}):
                server = create_bridge(ApprovalBroker(lambda *a: "deny"), port=18789)
                threading.Thread(target=run_secured, args=(server, "test-local-token", 18789), daemon=True).start()
                request_data = {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}},
                }
                request = urllib.request.Request(
                    "http://127.0.0.1:18789/mcp",
                    data=json.dumps(request_data).encode(),
                    headers={"Content-Type": "application/json", "Accept": "application/json, text/event-stream",
                             "X-Erzhan-Local-Auth": "test-local-token"},
                    method="POST",
                )
                denied = urllib.request.Request(
                    "http://127.0.0.1:18789/mcp",
                    data=json.dumps(request_data).encode(),
                    headers={"Content-Type": "application/json", "Accept": "application/json, text/event-stream"},
                    method="POST",
                )
                for attempt in range(30):
                    try:
                        with urllib.request.urlopen(request, timeout=3) as response:
                            content = response.read().decode()
                        self.assertIn('"protocolVersion"', content)
                        with self.assertRaises(urllib.error.HTTPError) as error:
                            urllib.request.urlopen(denied, timeout=3)
                        self.assertEqual(error.exception.code, 401)
                        return
                    except OSError:
                        if attempt == 29:
                            raise
                        time.sleep(0.1)


if __name__ == "__main__":
    unittest.main()
