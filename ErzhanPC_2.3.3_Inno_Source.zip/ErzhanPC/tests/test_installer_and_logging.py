import logging
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from connection_log import get_logger, log_path
from diagnostics import classify_tunnel_problem


class InstallerAndLoggingTests(unittest.TestCase):
    def test_tunnel_doctor_failures_have_clear_categories(self):
        self.assertIn("API key", classify_tunnel_problem("HTTP 401 unauthorized"))
        self.assertIn("permissions", classify_tunnel_problem("HTTP 403 forbidden"))
        self.assertIn("Network", classify_tunnel_problem("dial timed out"))
        self.assertIn("local MCP", classify_tunnel_problem("connection refused"))

    def test_inno_setup_is_offline_and_uses_standard_windows(self):
        script = (Path(__file__).resolve().parents[2] / "InstallerWin" / "ErzhanPC.iss").read_text(encoding="utf-8")
        self.assertIn("DefaultDirName={autopf}\\{#AppName}", script)
        self.assertIn("DisableWelcomePage=no", script)
        self.assertIn("DisableDirPage=no", script)
        self.assertIn("SetupLogging=yes", script)
        self.assertIn("CurInstallProgressChanged", script)
        self.assertIn("Source: \"..\\ErzhanPC\\dist\\ErzhanPC\\*\"", script)
        self.assertNotIn("DownloadTemporaryFile", script)

    def test_connection_log_is_rotating_and_contains_no_token(self):
        with tempfile.TemporaryDirectory() as root, patch.dict(os.environ, {"APPDATA": root}):
            logger = logging.getLogger("erzhanpc.connection")
            saved = logger.handlers[:]
            logger.handlers.clear()
            try:
                current = get_logger()
                current.info("Tunnel launched pid=123")
                for handler in current.handlers:
                    handler.flush()
                self.assertIn("Tunnel launched pid=123", log_path().read_text(encoding="utf-8"))
                self.assertTrue(any(hasattr(handler, "maxBytes") for handler in current.handlers))
            finally:
                for handler in logger.handlers:
                    handler.close()
                logger.handlers.clear()
                logger.handlers.extend(saved)


if __name__ == "__main__":
    unittest.main()
