import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def runtime_auth_headers(token):
    if not isinstance(token, str) or not token or any(character in token for character in "\r\n,"):
        raise ValueError("Invalid local authentication token")
    value = "X-Erzhan-Local-Auth: " + token
    return {"MCP_EXTRA_HEADERS": value, "MCP_DISCOVERY_EXTRA_HEADERS": value}


def tunnel_command(executable, profile, health_url_file):
    return [
        str(executable), "run", "--profile", str(profile),
        "--health.listen-addr", "127.0.0.1:0",
        "--health.url-file", str(health_url_file),
    ]


def reconnect_delay(failures):
    return min(60, 3 * 2 ** min(max(int(failures) - 1, 0), 5))


def tunnel_ready(health_url_file, timeout=0.25):
    try:
        url = Path(health_url_file).read_text(encoding="utf-8").strip().rstrip("/")
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or not parsed.port:
            return False
        if parsed.username or parsed.password or parsed.path not in ("", "/"):
            return False
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url + "/readyz", timeout=timeout) as response:
            return response.status == 200
    except (OSError, ValueError, urllib.error.URLError):
        return False
