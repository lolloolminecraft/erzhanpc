import hashlib
import json
import os
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


CAPABILITIES = {
    "screen": "Screen capture",
    "windows": "Window inspection",
    "input": "Keyboard and mouse",
    "shell": "PowerShell and applications",
    "files_read": "Read local files",
    "files_write": "Change local files",
    "devices": "Connected devices",
    "media_cloud": "Cloud video transcription",
}

FULL_READ = frozenset({"screen", "windows", "files_read", "devices"})
PRIVATE_ALLOWED = frozenset({"input"})
DEFAULT_ALLOW_SHORTCUT = "Ctrl+Shift+Y"


def settings_path():
    base = os.environ.get("APPDATA") or str(Path.home())
    return Path(base) / "ErzhanPC" / "settings.json"


class ApprovalBroker:
    def __init__(self, ask_user):
        self.ask_user = ask_user
        self.path = settings_path()
        self.lock = threading.RLock()
        self.enabled = False
        self.mode = "private"
        self.allow_always = set()
        self.input_lease_until = 0
        self.automation_profile = "manual"
        self.automation_until = 0
        self.allow_shortcut = DEFAULT_ALLOW_SHORTCUT
        self.load()

    def load(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.enabled = False
            self.mode = data.get("mode", "private") if data.get("mode") in {"private", "full"} else "private"
            self.allow_always = set(data.get("allow_always", [])) & FULL_READ
            self.allow_shortcut = self._validated_shortcut(data.get("allow_shortcut", DEFAULT_ALLOW_SHORTCUT))
        except (OSError, ValueError, TypeError):
            self.enabled = False
            self.mode = "private"
            self.allow_always = set()
            self.allow_shortcut = DEFAULT_ALLOW_SHORTCUT

    @staticmethod
    def _validated_shortcut(value):
        if not isinstance(value, str) or not re.fullmatch(r"(?:Ctrl|Alt|Shift)\+(?:(?:Ctrl|Alt|Shift)\+)?[A-Za-z0-9]{1,8}", value, re.IGNORECASE):
            raise ValueError("Shortcut must be a modifier combination such as Ctrl+Shift+Y")
        return value

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"enabled": False, "mode": self.mode, "allow_always": sorted(self.allow_always),
                   "allow_shortcut": self.allow_shortcut}
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)

    def _audit(self, capability, detail, result):
        record = {
            "time": datetime.now(timezone.utc).isoformat(),
            "capability": capability,
            "mode": self.mode,
            "result": result,
            "request_sha256": hashlib.sha256(str(detail).encode("utf-8")).hexdigest(),
        }
        try:
            log = self.path.with_name("activity.jsonl")
            log.parent.mkdir(parents=True, exist_ok=True)
            with log.open("a", encoding="utf-8") as file:
                file.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError:
            pass

    def set_enabled(self, value):
        with self.lock:
            self.enabled = bool(value)
            if not self.enabled:
                self.input_lease_until = 0
                self.automation_profile = "manual"
                self.automation_until = 0
            self.save()

    def set_mode(self, value):
        if value not in {"private", "full"}:
            raise ValueError("Unknown access mode")
        with self.lock:
            self.mode = value
            self.allow_always.clear()
            self.input_lease_until = 0
            self.automation_profile = "manual"
            self.automation_until = 0
            self.save()

    def grant_input_lease(self, duration=300):
        with self.lock:
            if not self.enabled or self.mode != "full":
                raise PermissionError("Full mode must be active")
            self.input_lease_until = time.monotonic() + min(max(int(duration), 1), 300)

    def set_allow_shortcut(self, value):
        shortcut = self._validated_shortcut(value)
        with self.lock:
            self.allow_shortcut = shortcut
            self.save()

    def grant_automation(self, profile, duration):
        if profile not in {"risk", "crazy"}:
            raise ValueError("Unknown automation mode")
        with self.lock:
            if not self.enabled or self.mode != "full":
                raise PermissionError("Full access must already be enabled locally")
            maximum = 900 if profile == "risk" else 120
            self.automation_until = time.monotonic() + min(max(int(duration), 1), maximum)
            self.automation_profile = profile
            self._audit("input", f"Local activation of {profile} mode", "local_automation_started")

    def stop_automation(self):
        with self.lock:
            self.automation_profile = "manual"
            self.automation_until = 0

    def revoke(self):
        with self.lock:
            self.allow_always.clear()
            self.save()

    def can_always(self, capability):
        return self.mode == "full" and capability in FULL_READ

    def request(self, capability, detail):
        if capability not in CAPABILITIES:
            raise PermissionError("Unknown operation")
        with self.lock:
            if not self.enabled:
                self._audit(capability, detail, "disabled")
                raise PermissionError("Access is paused on this PC")
            if self.mode == "private" and capability not in PRIVATE_ALLOWED:
                self._audit(capability, detail, "private_denied")
                raise PermissionError("Private mode blocks this operation")
            if self.mode == "full" and capability in FULL_READ:
                self._audit(capability, detail, "full_read")
                return
            if self.mode == "full" and capability == "input" and time.monotonic() < self.input_lease_until:
                self._audit(capability, detail, "input_lease")
                return
            if self.mode == "full" and time.monotonic() < self.automation_until:
                if self.automation_profile == "crazy":
                    self._audit(capability, detail, "crazy_auto_approved")
                    return
                if self.automation_profile == "risk" and capability == "input":
                    self._audit(capability, detail, "risk_input_auto_approved")
                    return
        decision = self.ask_user(capability, detail)
        with self.lock:
            if not self.enabled or (self.mode == "private" and capability not in PRIVATE_ALLOWED):
                self._audit(capability, detail, "revoked_during_approval")
                raise PermissionError("Access was revoked during approval")
            if decision == "always" and self.can_always(capability):
                self.allow_always.add(capability)
                self.save()
                self._audit(capability, detail, "approved")
            elif decision == "once":
                self._audit(capability, detail, "approved")
            else:
                self._audit(capability, detail, "denied")
                raise PermissionError("Action denied or confirmation timed out")

    def status(self):
        with self.lock:
            remaining = max(0, int(self.automation_until - time.monotonic()))
            return {"enabled": self.enabled, "mode": self.mode, "allow_always": sorted(self.allow_always),
                    "input_lease_seconds": max(0, int(self.input_lease_until - time.monotonic())),
                    "automation_profile": self.automation_profile if remaining else "manual",
                    "automation_seconds": remaining, "allow_shortcut": self.allow_shortcut}
