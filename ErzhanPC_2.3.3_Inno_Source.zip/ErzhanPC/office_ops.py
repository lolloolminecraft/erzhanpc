import hashlib
import os
import re
import secrets
import shutil
from datetime import datetime, timezone
from pathlib import Path


SUPPORTED = {".docx", ".xlsx", ".pptx", ".pdf"}


def _document_path(path, extensions=SUPPORTED):
    target = Path(os.path.expandvars(path)).expanduser().resolve(strict=True)
    if not target.is_file() or target.suffix.lower() not in extensions:
        raise ValueError("Unsupported office document")
    if target.stat().st_size > 25000000:
        raise ValueError("Document exceeds the 25 MB direct processing limit")
    return target


def _backup_and_save(target, save):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(3)
    backup = target.with_name(f"{target.name}.backup-{stamp}")
    temporary = target.with_name(f"{target.stem}.pending-{stamp}{target.suffix}")
    shutil.copy2(target, backup)
    try:
        save(str(temporary))
        shutil.copymode(target, temporary)
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return str(backup)


def _checksum(target):
    digest = hashlib.sha256()
    with target.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _verify_checksum(target, expected):
    if expected and _checksum(target) != expected.lower():
        raise ValueError("Document changed since it was inspected")


def office_preview(path, sheet_name=None, limit=12000):
    target = _document_path(path)
    ceiling = max(500, min(int(limit), 25000))
    extension = target.suffix.lower()
    if extension == ".docx":
        from docx import Document

        doc = Document(str(target))
        lines = [paragraph.text for paragraph in doc.paragraphs if paragraph.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                lines.append(" | ".join(cell.text for cell in row.cells))
        content = "\n".join(lines)
        return {"path": str(target), "type": "Word", "paragraphs": len(doc.paragraphs),
                "tables": len(doc.tables), "text": content[:ceiling], "truncated": len(content) > ceiling}
    if extension == ".xlsx":
        from openpyxl import load_workbook

        workbook = load_workbook(str(target), read_only=True, data_only=False, keep_links=False)
        try:
            if sheet_name and sheet_name not in workbook.sheetnames:
                raise ValueError("Sheet does not exist")
            sheet = workbook[sheet_name or workbook.sheetnames[0]]
            rows = []
            for index, row in enumerate(sheet.iter_rows(min_row=1, max_row=min(sheet.max_row, 80), max_col=min(sheet.max_column, 20), values_only=True)):
                if index >= 80:
                    break
                rows.append([value if isinstance(value, (type(None), str, int, float, bool)) else str(value) for value in row])
            result = {"path": str(target), "type": "Excel", "sheets": workbook.sheetnames,
                      "sheet": sheet.title, "rows": rows, "total_rows": sheet.max_row, "total_columns": sheet.max_column}
            return result
        finally:
            workbook.close()
    if extension == ".pptx":
        from pptx import Presentation

        presentation = Presentation(str(target))
        slides = []
        for number, slide in enumerate(presentation.slides, 1):
            if number > 30:
                break
            content = "\n".join(shape.text for shape in slide.shapes if shape.has_text_frame)
            slides.append({"number": number, "text": content[:ceiling]})
        return {"path": str(target), "type": "PowerPoint", "total_slides": len(presentation.slides),
                "slides": slides, "truncated": len(presentation.slides) > 30}
    from pypdf import PdfReader

    pdf = PdfReader(str(target))
    text = "\n".join((page.extract_text() or "") for page in pdf.pages[:min(len(pdf.pages), 12)])
    return {"path": str(target), "type": "PDF", "total_pages": len(pdf.pages),
            "text": text[:ceiling], "truncated": len(text) > ceiling or len(pdf.pages) > 12,
            "note": "Scanned PDFs may need OCR" if not text.strip() else ""}


def spreadsheet_set_cell(path, sheet_name, cell, value, expected_sha256=None):
    target = _document_path(path, {".xlsx"})
    _verify_checksum(target, expected_sha256)
    if not re.fullmatch(r"[A-Z]{1,3}[1-9][0-9]{0,6}", cell.upper()):
        raise ValueError("Cell must be a single A1 address")
    from openpyxl import load_workbook

    workbook = load_workbook(str(target))
    try:
        if sheet_name not in workbook.sheetnames:
            raise ValueError("Sheet does not exist")
        worksheet = workbook[sheet_name]
        address = cell.upper()
        old_value = worksheet[address].value
        if old_value == value:
            return {"path": str(target), "sheet": sheet_name, "cell": address, "changed": False}
        worksheet[address].value = value
        backup = _backup_and_save(target, workbook.save)
        return {"path": str(target), "sheet": sheet_name, "cell": address,
                "old_value": old_value, "new_value": value, "changed": True, "backup": backup}
    finally:
        workbook.close()


def word_replace_text(path, find_text, replace_with, replace_all=False, expected_sha256=None):
    target = _document_path(path, {".docx"})
    _verify_checksum(target, expected_sha256)
    if not find_text:
        raise ValueError("Find text must not be empty")
    from docx import Document

    doc = Document(str(target))
    paragraphs = list(doc.paragraphs)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                paragraphs.extend(cell.paragraphs)
    matching_runs = [(run, run.text.count(find_text)) for paragraph in paragraphs for run in paragraph.runs if find_text in run.text]
    count = sum(number for _, number in matching_runs)
    if count == 0:
        raise ValueError("Text not found within a single formatting run; use WPS for split-format text")
    if count > 1 and not replace_all:
        raise ValueError(f"Text has {count} matches; replace_all must be true")
    done = 0
    for run, number in matching_runs:
        if done and not replace_all:
            break
        run.text = run.text.replace(find_text, replace_with, -1 if replace_all else 1)
        done += number if replace_all else 1
    backup = _backup_and_save(target, doc.save)
    return {"path": str(target), "backup": backup, "replacements": done,
            "scope": "single formatting runs; original run styles retained"}
