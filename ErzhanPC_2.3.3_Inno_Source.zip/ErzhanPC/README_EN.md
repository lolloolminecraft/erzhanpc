# Erzhan PC 2.3.3

Erzhan PC is a local Windows 11 desktop companion for a private MCP connection from ChatGPT. Its supported path is the official OpenAI Secure MCP Tunnel.

## Installation

1. Run ErzhanPC_Setup_2.3.3.exe on a computer you own, after quitting any older Erzhan PC from the Windows tray.
2. Follow Welcome > Select Destination > Installing > Finish. The standard Inno Setup progress bar displays installation percentage.
3. The installer contains the prebuilt ErzhanPC.exe and the verified official tunnel-client.exe. It does not download Python packages or build the program on the end user's computer.
4. The installer defaults to Program Files, creates Start Menu and Windows startup shortcuts, and opens the dashboard. Access remains paused on launch until you explicitly start it.
5. In the Connection tab, click **Configure secure tunnel**. Select the installed tunnel-client.exe and paste your own tunnel ID and restricted runtime API key. Do not send the key through ChatGPT.
6. Open ChatGPT Plugins and add a private MCP connector using **Connection: Tunnel**, selecting that tunnel. The tunnel must be associated with the correct organization and ChatGPT workspace.
7. In Erzhan PC, switch to the access mode you want and click **Start access**. The OpenAI Tunnel status shows READY only after the local tunnel runtime responds successfully at `/readyz`.

Documentation:

- https://developers.openai.com/api/docs/guides/secure-mcp-tunnels
- https://platform.openai.com/settings/organization/tunnels
- https://platform.openai.com/settings/organization/api-keys
- https://chatgpt.com/#settings/Connectors

## Security

- The MCP listener binds only to 127.0.0.1:8787 and requires a new random local token at each application start. The application supplies the token only to its own tunnel-client child process using the officially supported MCP_EXTRA_HEADERS setting.
- The restricted OpenAI runtime key is protected with Windows DPAPI for the current Windows user.
- The agent always starts with remote access paused, including after Windows restarts. Access is never automatically resumed from a previous session.
- The tunnel ID and profile are stored under the current user's AppData, outside the installation directory. Installing an update over the same directory preserves the tunnel ID and encrypted runtime API key; do not remove the user's AppData or change the Windows account if you want to retain the key.
- New installs start in Private mode with access paused.
- The integrated frameless control center has Lucide icons, a draggable activity overlay, and a global approval hotkey configurable in Security (default Ctrl+Shift+Y).
- Risk auto-approval temporarily allows keyboard/mouse input for up to 15 minutes; UI controls can still delete files when clicked. Crazy mode separately auto-approves every capability for up to two minutes after the owner types CRAZY, including destructive actions. Both expire automatically and are not saved to disk. Use STOP ALL ACCESS at any time.
- Private mode blocks screen capture, window inspection, process lists, device lists, files and PowerShell. Explicitly approved keyboard/mouse actions are the only remote PC actions allowed.
- Full mode allows screen and file observations. Shell execution, application launches, keyboard/mouse input, file creation, rename and recycling require confirmation on the computer.
- Media tools now return photo previews, video timestamps and video contact sheets as MCP images. Video analysis is based on sampled frames, not full audio or speech transcription.
- Text edits require local approval, perform exact search-and-replace and save a separate backup; moving a file refuses to overwrite another file.
- Folder organization supports a dry-run preview plus an exact checksum-guarded apply step. It only moves top-level files into Images, Videos, Audio, Documents, Archives, Installers and Other, skips incomplete downloads and existing destination names, and never deletes a file.
- Office Preview extracts text and worksheet cells from DOCX, XLSX, PPTX and text-based PDF files, with bounded responses. The tools can update a single XLSX cell or replace text within a single DOCX formatting run, creating a backup before every change. Complex documents, preserved macros and unsupported formatting should be edited interactively in WPS instead.
- Open Document launches an existing Office, PDF or text file with the current Windows default association (including WPS Office where configured). WPS editing continues through the existing UI Automation and keyboard tools with local approval, and needs real-world workflow testing.
- Windows UI tools now support reading accessible text, editing accessible Edit controls, focusing windows and batching up to 25 actions. WPS-specific controls may not expose their value through UI Automation; screenshot-guided interaction remains available for those applications.
- Window Capture returns a focused application screenshot without sending every monitor, reducing transfer size on large multi-monitor desktops.
- Speech transcription supports up to one hour per asynchronous job, processed in six-minute sections using the current OpenAI `gpt-transcribe` model. It needs a separately configured API key saved with Windows DPAPI, incurs API charges, and sends audio to OpenAI only after local approval. Visual video analysis remains available without a speech API key.
- To speed up interactive UI tasks, the local user can grant a non-persistent five-minute keyboard/mouse lease. This is powerful: UI actions can themselves launch commands or modify files. Use it only while supervising the computer.
- Persistent allow-forever for PowerShell and file modifications is not supported. Crazy mode is a separate explicitly unlocked, time-limited exception.
- The application saves action metadata and hashes, not PowerShell command contents or API keys, in the activity log.
- The Stop access action pauses requests and stops the outgoing tunnel-client process. Start access reconnects it. Neither action guarantees stopping a command already running.

The current Secure MCP Tunnel authorizes the OpenAI organization and workspace, but this release does **not** implement cryptographically authenticated per-person identities. User allowlisting and revocation require OAuth for the MCP connector and should not be simulated by a user-entered display name. Do not share this connector until that is implemented.

## Multiple computers

Install the same EXE separately on each Windows PC. Two personal PCs can use the same tunnel ID and restricted runtime key when **only one PC has Start access enabled at any time**. Press Stop access on the first PC, wait until its tunnel process reports NOT RUNNING, then press Start access on the second. Reusing a tunnel means there is one ChatGPT connector, and the connected PC changes with the active local agent. Do not enable both PCs at once. Separate tunnel IDs and keys are stronger isolation if independent simultaneous access is later needed.

## Diagnostics

- Dashboard Overview: local listener, access mode, tunnel readiness and recent action.
- Tunnel health uses a dynamically selected loopback port and records its base URL in AppData/Roaming/ErzhanPC/tunnel-health.url. It does not require port 8080 to be available.
- Dashboard Windows: accessible UI Automation tree.
- Dashboard Activity: last actions, approval results and timestamps.
- Installation log: destination/install.log.
- Tunnel process log: AppData/Roaming/ErzhanPC/tunnel.log.
- Rotating connection log: AppData/Roaming/ErzhanPC/logs/connection.log; press **Open logs** on the Connection tab.
- **Check connection** checks the local listener, tunnel readiness and the official `tunnel-client doctor` command without displaying the stored API key.
- Local MCP server startup errors: AppData/Roaming/ErzhanPC/server-error.log. The tunnel waits for local port 8787 before starting.
- If the tunnel process exits unexpectedly, Erzhan PC retries with a capped exponential delay while local access is enabled. ChatGPT may still need a separate plugin reconnect if authorization expires.
- Runtime key: AppData/Roaming/ErzhanPC/runtime.secret, encrypted with Windows DPAPI.

The built-in updater uses a signed GitHub channel owned by lolloolminecraft, with the publisher's Ed25519 public key pinned in the app. It checks every six hours. Small ZIP patches (changed modules only, maximum 8 MB) are automatically downloaded after Ed25519 and SHA-256 checks; activating one requires local restart confirmation. The original modules remain as a fallback. The public repository does not conceal patch contents: signing is not encryption. Rebuilding the app's updater still needs a full signed installer. See InstallerWin/UPDATES.md. The Inno Setup installer replaces files in its own installation; older per-user installations may remain in LocalAppData until the owner removes them.

The Workspace tab can open Windows Sandbox if installed. It does not yet create a second agent-controlled screen: Windows virtual desktops share mouse and keyboard, while Windows Sandbox needs a separate agent deployment for remote control. An independent second PC/VM is the supported approach.

Do not share your runtime secret file, complete tunnel logs or API keys with anyone. When reporting an error, redact user names, file paths and private data.

## Build and verification

To build the new installer on Windows, install Python 3.11+ and Inno Setup 6, then run InstallerWin/Build_Installer.cmd. This builds a PyInstaller one-directory package, fetches the official tunnel-client once into a SHA-256-verified cache, and compiles InstallerWin/ErzhanPC.iss into InstallerWin/output/ErzhanPC_Setup_2.3.3.exe. Python and Inno Setup are only needed by the builder, not by the end user.

On Linux, run the Python test suite. The installer itself must be built and tested on a real Windows machine; Linux source tests cannot confirm GUI startup, secure tunnel operation, or ChatGPT authorization end-to-end.
