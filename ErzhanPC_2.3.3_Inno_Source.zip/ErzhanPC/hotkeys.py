import ctypes
import os
import threading
from ctypes import wintypes

from PySide6.QtCore import QObject, Signal


MODIFIERS = {"ALT": 0x0001, "CTRL": 0x0002, "SHIFT": 0x0004}
WM_HOTKEY = 0x0312
WM_QUIT = 0x0012
HOTKEY_ID = 39027


def decode_shortcut(value):
    parts = [piece.strip().upper() for piece in value.split("+")]
    if len(parts) < 2 or not parts[-1] or any(piece not in MODIFIERS for piece in parts[:-1]):
        raise ValueError("Use Ctrl/Alt/Shift plus a letter or number")
    if len(set(parts[:-1])) != len(parts[:-1]):
        raise ValueError("Repeated modifier")
    key = parts[-1]
    if len(key) != 1 or not key.isascii() or not key.isalnum():
        raise ValueError("The final key must be one letter or digit")
    mask = 0
    for piece in parts[:-1]:
        mask |= MODIFIERS[piece]
    return mask | 0x4000, ord(key)


class GlobalApprovalHotkey(QObject):
    pressed = Signal()
    failed = Signal(str)

    def __init__(self, shortcut, parent=None):
        super().__init__(parent)
        self.shortcut = shortcut
        self.thread = None
        self.thread_id = 0

    def start(self):
        if os.name != "nt":
            return
        self.stop()
        self.thread = threading.Thread(target=self._run, daemon=True, name="ErzhanApprovalHotkey")
        self.thread.start()

    def stop(self):
        thread_id = self.thread_id
        if os.name == "nt" and thread_id:
            ctypes.windll.user32.PostThreadMessageW(thread_id, WM_QUIT, 0, 0)
        if self.thread is not None:
            self.thread.join(timeout=1)
        self.thread = None
        self.thread_id = 0

    def _run(self):
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        message = wintypes.MSG()
        user32.PeekMessageW(ctypes.byref(message), None, 0, 0, 0)
        self.thread_id = kernel32.GetCurrentThreadId()
        try:
            modifiers, key = decode_shortcut(self.shortcut)
            if not user32.RegisterHotKey(None, HOTKEY_ID, modifiers, key):
                self.failed.emit("Hotkey is already used by Windows or another application")
                return
            try:
                while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
                    if message.message == WM_HOTKEY and message.wParam == HOTKEY_ID:
                        self.pressed.emit()
            finally:
                user32.UnregisterHotKey(None, HOTKEY_ID)
        except ValueError as error:
            self.failed.emit(str(error))
