# Erzhan PC 2.3 — signed small updates

The default update feed is `https://raw.githubusercontent.com/lolloolminecraft/erzhanpc/main/channel.json`.
The app pins the publisher's Ed25519 public key and checks this feed every six hours, beginning shortly after startup. The private signing key is not part of the repository or installer.

## Publish a small update

1. Prepare a cumulative ZIP containing changed root-level `.py` modules and optional `icons/*.svg` assets, without DLLs, executables or other entries. Include all changes since the installed 2.3.0 baseline. This permits upgrades directly from 2.3.0 to the newest patch.
2. Review and test the ZIP locally. Keep it under 8 MB compressed and 24 MB uncompressed.
3. Upload it to an HTTPS URL such as `https://raw.githubusercontent.com/lolloolminecraft/erzhanpc/main/releases/2.3.1.zip`.
4. Using the separate encrypted publisher private key and password, sign the package:

   `python sign_release.py sign publisher.pem 2.3.1.zip 2.3.1 https://raw.githubusercontent.com/lolloolminecraft/erzhanpc/main/releases/2.3.1.zip channel-next.json --kind patch --base-version 2.3.0`

5. Publish the signed `channel-next.json` as `channel.json`. This is the mutable feed path.

The app verifies HTTPS, Ed25519 publisher signature, SHA-256, module names, ZIP paths and size limits. It downloads a valid small patch automatically and asks to restart. On restart, the verified ZIP importer loads changed modules. The original bundled application remains as a fallback.

An update to the loader itself requires a new full installer because `launcher.py` and `update_engine.py` are deliberately excluded from patch ZIPs.

## Security

- The repository is public. Ed25519 signing authenticates the publisher but does not encrypt or hide files.
- The encrypted private signing key must be backed up separately, never committed to GitHub.
- The pinned publisher public key is `17017d88c7ee38995874c2a894d150fe51b30bb022620b07fe41f82d8bc79c1d`.
- Trusted-publisher settings can only be changed through the local UI.
- Reducing Defender/SmartScreen false positives requires a legitimate Windows Authenticode certificate and testing. Never disable antivirus for updates.
