#define AppName "Erzhan PC"
#define AppVersion "2.3.3"
#define AppExe "ErzhanPC.exe"

[Setup]
AppId={{D7537F29-5B45-4F1D-A838-FAC41DBD4D23}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
OutputDir=output
OutputBaseFilename=ErzhanPC_Setup_{#AppVersion}
SetupIconFile=..\ErzhanPC\icons\ErzhanPC.ico
UninstallDisplayIcon={app}\{#AppExe}
WizardStyle=modern
DisableWelcomePage=no
DisableDirPage=no
DisableReadyPage=yes
DisableFinishedPage=no
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
Compression=lzma2/normal
SolidCompression=yes
SetupLogging=yes
CloseApplications=yes
RestartApplications=no
UsePreviousAppDir=yes

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Files]
Source: "..\ErzhanPC\dist\ErzhanPC\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{commonstartup}\{#AppName}"; Filename: "{app}\{#AppExe}"

[InstallDelete]
Type: files; Name: "{userstartup}\Erzhan PC.lnk"

[Run]
Filename: "{app}\{#AppExe}"; Parameters: "--show"; Description: "Запустить Erzhan PC"; Flags: nowait postinstall skipifsilent runasoriginaluser

[Code]
var
  ProgressPercent: TNewStaticText;

procedure InitializeWizard;
begin
  ProgressPercent := TNewStaticText.Create(WizardForm);
  ProgressPercent.Parent := WizardForm.InstallingPage;
  ProgressPercent.AutoSize := True;
  ProgressPercent.Caption := '0%';
  ProgressPercent.Left := WizardForm.ProgressGauge.Left;
  ProgressPercent.Top := WizardForm.ProgressGauge.Top + WizardForm.ProgressGauge.Height + ScaleY(8);
end;

procedure CurInstallProgressChanged(CurProgress, MaxProgress: Integer);
begin
  if MaxProgress > 0 then
    ProgressPercent.Caption := IntToStr(Round(100.0 * CurProgress / MaxProgress)) + '%';
end;
