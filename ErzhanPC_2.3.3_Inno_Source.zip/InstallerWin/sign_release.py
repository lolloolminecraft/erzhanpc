import argparse
import base64
import getpass
import hashlib
import json
import re
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def release_payload(version, url, sha256):
    return json.dumps({"sha256": sha256, "url": url, "version": version},
                      sort_keys=True, separators=(",", ":")).encode("utf-8")


def patch_payload(version, base_version, url, sha256):
    return json.dumps({"kind": "patch", "base_version": base_version, "version": version,
                       "sha256": sha256, "url": url}, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def idle_payload(version):
    return json.dumps({"kind": "idle", "version": version}, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def sign_idle(private_path, password, version, manifest_path):
    private = serialization.load_pem_private_key(Path(private_path).read_bytes(), password.encode("utf-8"))
    manifest = {"kind": "idle", "version": version,
                "signature": base64.b64encode(private.sign(idle_payload(version))).decode("ascii")}
    with Path(manifest_path).open("x", encoding="utf-8") as stream:
        json.dump(manifest, stream, ensure_ascii=False, indent=2)
    return manifest


def create_key(path, password):
    if len(password) < 12:
        raise ValueError("Use a publisher signing password with at least 12 characters")
    private = Ed25519PrivateKey.generate()
    output = Path(path)
    pem = private.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
        serialization.BestAvailableEncryption(password.encode("utf-8")),
    )
    with output.open("xb") as stream:
        stream.write(pem)
    public = private.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw,
    )
    return public.hex()


def sign_release(private_path, password, exe_path, version, url, manifest_path,
                 kind="installer", base_version=None):
    if not re.fullmatch(r"\d{1,4}\.\d{1,4}\.\d{1,4}", version):
        raise ValueError("Invalid version")
    suffix = ".zip" if kind == "patch" else ".exe"
    if not url.startswith("https://") or not url.split("?", 1)[0].lower().endswith(suffix):
        raise ValueError("Update URL must use HTTPS and have the correct file extension")
    if kind == "patch" and (not base_version or not re.fullmatch(r"\d{1,4}\.\d{1,4}\.\d{1,4}", base_version)):
        raise ValueError("A patch must have a valid base version")
    private = serialization.load_pem_private_key(Path(private_path).read_bytes(), password.encode("utf-8"))
    digest = hashlib.sha256(Path(exe_path).read_bytes()).hexdigest()
    payload = patch_payload(version, base_version, url, digest) if kind == "patch" else release_payload(version, url, digest)
    signature = private.sign(payload)
    manifest = {"version": version, "url": url, "sha256": digest,
                "signature": base64.b64encode(signature).decode("ascii")}
    if kind == "patch":
        manifest.update({"kind": "patch", "base_version": base_version})
    with Path(manifest_path).open("x", encoding="utf-8") as stream:
        json.dump(manifest, stream, ensure_ascii=False, indent=2)
    return manifest


def main():
    parser = argparse.ArgumentParser(description="Sign trusted Erzhan PC releases")
    actions = parser.add_subparsers(dest="operation", required=True)
    key = actions.add_parser("keygen")
    key.add_argument("private_pem")
    sign = actions.add_parser("sign")
    sign.add_argument("private_pem")
    sign.add_argument("installer_exe")
    sign.add_argument("version")
    sign.add_argument("https_installer_url")
    sign.add_argument("output_manifest")
    sign.add_argument("--kind", choices=["installer", "patch"], default="installer")
    sign.add_argument("--base-version")
    idle = actions.add_parser("idle")
    idle.add_argument("private_pem")
    idle.add_argument("version")
    idle.add_argument("output_manifest")
    args = parser.parse_args()
    password = getpass.getpass("Signing key password: ")
    if args.operation == "keygen":
        print("PUBLISHER PUBLIC KEY: " + create_key(args.private_pem, password))
    elif args.operation == "idle":
        sign_idle(args.private_pem, password, args.version, args.output_manifest)
        print("Signed idle channel created: " + args.output_manifest)
    else:
        sign_release(args.private_pem, password, args.installer_exe, args.version,
                     args.https_installer_url, args.output_manifest, args.kind, args.base_version)
        print("Signed manifest created: " + args.output_manifest)


if __name__ == "__main__":
    main()
