@echo off
setlocal
cd /d "%~dp0"

echo [1/3] Building Windows application...
call "..\ErzhanPC\Build_Windows.cmd"
if errorlevel 1 exit /b 1
cd /d "%~dp0"

echo [2/3] Preparing verified official tunnel client...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "..\ErzhanPC\tools\download_tunnel.ps1" -Destination "..\ErzhanPC\dist\ErzhanPC" -CacheDirectory "cache"
if errorlevel 1 exit /b 1
if not exist "..\ErzhanPC\dist\ErzhanPC\tunnel-client.exe" exit /b 1

echo [3/3] Creating Inno Setup installer...
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 7\ISCC.exe"
if not defined ISCC for %%I in (ISCC.exe) do if not "%%~$PATH:I"=="" set "ISCC=%%~$PATH:I"
if not defined ISCC (
    echo Inno Setup 6 is required: https://jrsoftware.org/isdl.php
    exit /b 1
)
"%ISCC%" "ErzhanPC.iss"
if errorlevel 1 exit /b 1
echo Installer ready: InstallerWin\output\ErzhanPC_Setup_2.3.3.exe
exit /b 0
