import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "InstallerWin" / "base_manifest.json"
CORE = {"launcher.py", "update_engine.py"}


def release_files():
    items = {}
    for path in sorted((ROOT / "ErzhanPC").glob("*.py")):
        if path.name not in CORE:
            items[path.name] = path
    for path in sorted((ROOT / "ErzhanPC" / "icons").glob("*.svg")):
        if path.name != "ErzhanPC.svg":
            items["icons/" + path.name] = path
    return items


def baseline_files():
    return {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in release_files().items()}


def create_baseline():
    if BASELINE.exists():
        raise FileExistsError("2.3.0 baseline already exists and must not be overwritten")
    BASELINE.write_text(json.dumps(baseline_files(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return BASELINE


def create_patch(version, output):
    if not re.fullmatch(r"\d{1,4}\.\d{1,4}\.\d{1,4}", version):
        raise ValueError("Invalid patch version")
    before = json.loads(BASELINE.read_text(encoding="utf-8"))
    changed = {name: path for name, path in release_files().items()
               if hashlib.sha256(path.read_bytes()).hexdigest() != before.get(name)}
    if not changed:
        raise ValueError("Nothing has changed since the 2.3.0 baseline")
    output = Path(output)
    if output.exists():
        raise FileExistsError("Refusing to overwrite an existing signed patch")
    with zipfile.ZipFile(output, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, path in sorted(changed.items()):
            bundle.write(path, arcname=name)
    if output.stat().st_size > 8_000_000:
        output.unlink()
        raise ValueError("Patch exceeds 8 MB; provide a new installer")
    return changed


def main():
    parser = argparse.ArgumentParser(description="Package cumulative Erzhan PC module updates")
    parser.add_argument("action", choices=["baseline", "patch"])
    parser.add_argument("--version", default="")
    parser.add_argument("--output", default="")
    args = parser.parse_args()
    if args.action == "baseline":
        print("Baseline: " + str(create_baseline()))
    else:
        target = args.output or ("ErzhanPC_Patch_" + args.version + ".zip")
        files = create_patch(args.version, target)
        print("Patch: " + target + " (" + ", ".join(sorted(files)) + ")")


if __name__ == "__main__":
    main()
